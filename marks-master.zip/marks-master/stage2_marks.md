| Mark | Max | Design Task | Comments |
| ---- | --- | ----------- | -------- |
| 1    | 2   | 1A | Time in ms incorrect |
| 0    | 2   | 2A | Wrong output pin use |
| 2    | 2   | MYLIB Atimer |  |
| 2    | 2   | MYLIB Atimer Configure |  |
| 1    | 1   | 1B |  |
| 2    | 2   | 2B |  |
| 2    | 2   | 3B |  |
| 1    | 2   | MYLIB Joystick and PWM| PWM Set & Get should be #define |
| 1    | 1   | Code Style |  |