| Mark | Max | Design Task | Comments |
| ---- | --- | ----------- | -------- |
| 2    | 2   | CAG Simulator |    |
| 2    | 2   | CAG Display |    |
| 2    | 2   | CAG Input |    |
| 2    | 2   | Code Quality |     |
| 2    | 2   | Folder Structure |     |
| 0    | 0   | Deductions |     |
