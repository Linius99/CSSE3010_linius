| Mark | Max | Design Task |
| ---- | --- | ----------- |
| 0    | 3   | 1A |
| 0    | 3   | 2A |
| 0    | 3   | 1B |
| 0    | 1   | Code Style |
| 0    | 2   | MYLIB |
| 0    | 1   | Workbook |
| 0    | 1   | Schematic |
| 0    | 2   | Flow Charts | 
| 1    | 2   | Worksheet |
