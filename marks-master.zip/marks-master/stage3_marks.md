| Mark | Max | Design Task | Comment |
| ---- | --- | ----------- | ------- |
| 4    | 4   | 1A |  |
| 4    | 4   | 1B & 2B | |
| 2    | 2   | 3B |  |
| 2    | 2   | Keypad HAL MYLIB |  |
| 2    | 2   | Hamming LIB MYLIB |  |
| 1    | 1   | MYLIB Configuration |  |
| 1    | 1   | Code Style |  |
