| Mark | Max | Design Task | Comments |
| ---- | --- | ----------- | -------- |
| 3    | 3   | 1 |  HAL_init function should be called at the start of the corresponding task, instead of repeating the same code in os_init. Also the ledbar task can just call hal_write directly, the wrapper function is not needed  |
| 4    | 4   | 2 |    |
| 2    | 2   | 3 |    |
| 1    | 1   | Code Style |     |
