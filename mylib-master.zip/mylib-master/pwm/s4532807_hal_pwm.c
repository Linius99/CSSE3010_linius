/** 
 **************************************************************
 * @file mylib/s4532807_hal_pwm.c
 * @author Linius Zaman 45328077
 * @date 27/03/2020
 * @brief mylib pwm driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_pwm_init(void) - initialise and start PWM outputs
 * extern uint32_t s4532807_hal_pwm_dc_get(void) - return current duty cycle
 * extern void s4532807_hal_pwm_dc_set(int value) - set duty cycle to 
 * given value 
 *************************************************************** 
 */

#include "s4532807_hal_pwm.h"

TIM_HandleTypeDef S4532807_HAL_PWM_TIMER_HANDLER;

/*
 * This function does all of the necessary initialisation for the pwm.
 */
extern void s4532807_hal_pwm_init() {

    GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OC_InitTypeDef PWMConfig;

	uint16_t PrescalerValue = 0;

    S4532807_HAL_PWM_TIMER_CLK();
	S4532807_HAL_PWM_PINCLK;

	GPIO_InitStructure.Pin = S4532807_HAL_PWM_PIN;
	GPIO_InitStructure.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStructure.Pull = GPIO_NOPULL;
	GPIO_InitStructure.Speed = GPIO_SPEED_FAST;
	GPIO_InitStructure.Alternate = S4532807_HAL_PWM_PINGPIOAF;
	HAL_GPIO_Init(S4532807_HAL_PWM_PINGPIOPORT, &GPIO_InitStructure);

	PrescalerValue = (uint16_t) (SystemCoreClock 
                                / S4532807_HAL_PWM_CLOCKFREQ) - 1;

	S4532807_HAL_PWM_TIMER_HANDLER.Instance = S4532807_HAL_PWM_TIMER;
	S4532807_HAL_PWM_TIMER_HANDLER.Init.Period = S4532807_HAL_PWM_PERIOD;
	S4532807_HAL_PWM_TIMER_HANDLER.Init.Prescaler = PrescalerValue;
	S4532807_HAL_PWM_TIMER_HANDLER.Init.ClockDivision = 0;
	S4532807_HAL_PWM_TIMER_HANDLER.Init.RepetitionCounter = 0;
	S4532807_HAL_PWM_TIMER_HANDLER.Init.CounterMode = TIM_COUNTERMODE_UP;

	PWMConfig.OCMode = TIM_OCMODE_PWM1;
	PWMConfig.Pulse = S4532807_HAL_PWM_PULSEPERIOD;
	PWMConfig.OCPolarity = TIM_OCPOLARITY_HIGH;
	PWMConfig.OCNPolarity = TIM_OCNPOLARITY_HIGH;
	PWMConfig.OCFastMode = TIM_OCFAST_DISABLE;
	PWMConfig.OCIdleState = TIM_OCIDLESTATE_RESET;
	PWMConfig.OCNIdleState = TIM_OCNIDLESTATE_RESET;

	HAL_TIM_PWM_Init(&S4532807_HAL_PWM_TIMER_HANDLER);
	HAL_TIM_PWM_ConfigChannel(&S4532807_HAL_PWM_TIMER_HANDLER, 
                                &PWMConfig, S4532807_HAL_PWM_CHANNEL);

	HAL_TIM_PWM_Start(&S4532807_HAL_PWM_TIMER_HANDLER, 
                       S4532807_HAL_PWM_CHANNEL);
}

/*
 * This function returns the duty cycle.
 */
extern uint32_t s4532807_hal_pwm_dc_get(void) {
    float pulsePeriod = __HAL_TIM_GET_COMPARE(&S4532807_HAL_PWM_TIMER_HANDLER,
                        S4532807_HAL_PWM_CHANNEL);
    
    return pulsePeriod / (float) S4532807_HAL_PWM_PERIOD;
}

/*
 * This function sets the duty cycle based on the given value.
 */
extern void s4532807_hal_pwm_dc_set(float value) {
    __HAL_TIM_SET_COMPARE(&S4532807_HAL_PWM_TIMER_HANDLER,
                        S4532807_HAL_PWM_CHANNEL, 
                        S4532807_HAL_PWM_PERIOD * value);
}
