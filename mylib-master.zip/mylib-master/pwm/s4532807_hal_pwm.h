/** 
 **************************************************************
 * @file mylib/s4532807_hal_pwm.h
 * @author Linius Zaman 45328077
 * @date 27/03/2020
 * @brief mylib pwm driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_pwm_init(void) - initialise and start PWM outputs
 * extern uint32_t s4532807_hal_pwm_dc_get(void) - return current duty cycle
 * extern void s4532807_hal_pwm_dc_set(int value) - set duty cycle to 
 * given value 
 *************************************************************** 
 */

#ifndef s4532807_hal_pwm_h_
#define s4532807_hal_pwm_h_

#include "board.h"
#include "processor_hal.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#ifdef S4532807_MYLIB_CONFIGURE_INC
#include "s4532807_hal_mylib_configure.h"
#endif

#ifndef S4532807_HAL_PWM_CLOCKFREQ
#define S4532807_HAL_PWM_CLOCKFREQ 100
#endif

#ifndef S4532807_HAL_PWM_PULSEPERIOD
#define S4532807_HAL_PWM_PULSEPERIOD 100
#endif

#ifndef S4532807_HAL_PWM_PERIOD
#define S4532807_HAL_PWM_PERIOD 100
#endif

#ifndef S4532807_HAL_PWM_CHANNEL
#define S4532807_HAL_PWM_CHANNEL 0
#endif

#ifndef S4532807_HAL_PWM_TIMER
#define S4532807_HAL_PWM_TIMER 0
#endif

#ifndef S4532807_HAL_PWM_TIMER_CLK
#define S4532807_HAL_PWM_TIMER_CLK 0
#endif

#ifndef S4532807_HAL_PWM_TIMER_HANDLER
#define S4532807_HAL_PWM_TIMER_HANDLER 0
#endif

#ifndef S4532807_HAL_PWM_PIN
#define S4532807_HAL_PWM_PIN BRD_D0_PIN
#endif

#ifndef S4532807_HAL_PWM_PINGPIOPORT
#define S4532807_HAL_PWM_PINGPIOPORT BRD_D0_GPIO_PORT
#endif

#ifndef S4532807_HAL_PWM_PINGPIOAF
#define S4532807_HAL_PWM_PINGPIOAF 0
#endif

#ifndef S4532807_HAL_PWM_PINCLK
#define S4532807_HAL_PWM_PINCLK 0
#endif

#ifndef S4532807_HAL_PWM_PINCLKSPEED
#define S4532807_HAL_PWM_PINCLKSPEED 0
#endif

#define S4532807_HAL_PWM_DC_GET() s4532807_hal_pwm_dc_get()
#define S4532807_HAL_PWM_DC_SET() s4532807_hal_pwm_dc_set() 

/*
 * This function does all of the necessary initialisation for the pwm.
 */
extern void s4532807_hal_pwm_init(void);

/*
 * This function returns the duty cycle.
 */
extern uint32_t s4532807_hal_pwm_dc_get(void);

/*
 * This function sets the duty cycle based on the given value.
 */
extern void s4532807_hal_pwm_dc_set(float value);

#endif
