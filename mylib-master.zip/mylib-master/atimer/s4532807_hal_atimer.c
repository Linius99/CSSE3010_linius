/** 
 **************************************************************
 * @file mylib/s4532807_hal_atimer.c
 * @author Linius Zaman 45328077
 * @date 27/03/2020
 * @brief mylib atimer driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_timer_init() - initialise and start atimer from zero
 * extern uint32_t s4532807_hal_atimer_timer_getms() - return atimer value
 * extern void s4532807_hal_atimer_timer_reset() - reset atimer
 * extern void s4532807_hal_atimer_timer_pause() - pause atimer
 * extern void s4532807_hal_atimer_timer_resume() - resume atimer
 * extern void s4532807_hal_atimer_clkspeed_set(int frequency) - 
 * set atimer clock speed 
 * extern void s4532807_hal_atimer_period_set(int period) - set atimer period
 * extern uint32_t s4532807_hal_atimer_timer_read(void) - 
 * read atimer counter value
 * extern void s4532807_hal_atimer_init_pin() - Init GPIO pin for atimer
 ***************************************************************
 * INTERNAL FUNCTIONS
 ***************************************************************
 * void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
 * - ISR callback function for incrementing atimerCounterVal
 * void TIM3_IRQHandler(void) - Handler for IRQ
 *************************************************************** 
 */

#include "s4532807_hal_atimer.h"

TIM_HandleTypeDef TIM_Init;

/* 
 * Function initialises all the atimer variables and performs necessary setup.
 */
extern void s4532807_hal_atimer_init() {
    timerRunning = 1;    
    pinStatus = 0;
    
    unsigned short PrescalerValue;    
    
    __TIM3_CLK_ENABLE();
    PrescalerValue = (uint16_t) ((SystemCoreClock / 1) / atimerClkspeedVal) - 1;

    atimerClkspeedVal = S4532807_HAL_ATIMER_CLKSPEED;
    atimerPeriodVal = S4532807_HAL_ATIMER_PERIOD;
    atimerPrescalerVal = PrescalerValue;
    atimerCounterVal = 0;
    
    TIM_Init.Instance = TIM3;
    TIM_Init.Init.Period = (atimerClkspeedVal / 1000) * atimerPeriodVal;
    TIM_Init.Init.Prescaler = PrescalerValue;
    TIM_Init.Init.ClockDivision = 0;
    TIM_Init.Init.RepetitionCounter = 0;
    TIM_Init.Init.CounterMode = TIM_COUNTERMODE_UP;

    HAL_TIM_Base_Init(&TIM_Init);
    
    HAL_NVIC_SetPriority(TIM3_IRQn, 10, 0);

    HAL_NVIC_EnableIRQ(TIM3_IRQn);
    
    HAL_TIM_Base_Start_IT(&TIM_Init); 

}

/*
 * This function returns the atimer counter value.
 */
extern uint32_t s4532807_hal_atimer_timer_read(void) {
    return atimerCounterVal;    
}

/*
 * Returns how many milliseconds have passed based on the period and counter.
 */
extern uint32_t s4532807_hal_atimer_timer_getms(void) {
    return atimerCounterVal * atimerPeriodVal;
}

/*
 * Resets the atimer counter.
 */
extern void s4532807_hal_atimer_timer_reset(void) {
    atimerCounterVal = 0;
}

/*
 * Pauses the atimer counter by preventing it from incrementing.
 * (Incrementing stops when timerRunning variable is set to 0)
 */
extern void s4532807_hal_atimer_timer_pause(void) {
    timerRunning = 0;
}

/*
 * Resumes the atimer counter by letting it increment again.
 * (Incrementing continues when timerRunning variable is set to 1)
 */
extern void s4532807_hal_atimer_timer_resume(void) {
    timerRunning = 1;
}

/*
 * This function sets the clock speed of the atimer 
 * based on the given frequency.
 */
extern void s4532807_hal_atimer_clkspeed_set(int frequency) {
    atimerClkspeedVal = frequency;
    atimerPrescalerVal = (uint16_t) (SystemCoreClock / atimerClkspeedVal) - 1;
    
    __HAL_TIM_SET_PRESCALER(&TIM_Init, atimerPrescalerVal);

    s4532807_hal_atimer_period_set(atimerPeriodVal);
}

/*
 * This function sets the period of the atimer using the value given.
 */
extern void s4532807_hal_atimer_period_set(int period) {
    atimerPeriodVal = period;
    
    int periodCount = (atimerClkspeedVal / 1000) * atimerPeriodVal;
    __HAL_TIM_SET_AUTORELOAD(&TIM_Init, periodCount); 
}

/*
 * Function initialises the atimer pin.
 */
extern void s4532807_hal_atimer_init_pin(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    S4532807_HAL_ATIMER_PINCLK;

    GPIO_InitStructure.Pin = S4532807_HAL_ATIMER_PIN;
    GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStructure.Pull = GPIO_PULLDOWN;
    GPIO_InitStructure.Speed = GPIO_SPEED_FAST;
    HAL_GPIO_Init(S4532807_HAL_ATIMER_PINPORT, &GPIO_InitStructure);
}

/*
 * Callback function for timer, increments the timer if timerRunning is set to 1
 * Toggles the pinStatus and writes to the GPIO pin
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM3) {
        if (timerRunning == 1) {
            atimerCounterVal++;
            
            if (pinStatus == 1) {
                pinStatus = 0;
            } else {
                pinStatus = 1;
            }
            
            HAL_GPIO_WritePin(S4532807_HAL_ATIMER_PINPORT, 
                S4532807_HAL_ATIMER_PIN, pinStatus);
        }
    }
    
}

/*
 * IRQ handler for timer 3, overrides default handler
 */
void TIM3_IRQHandler(void) {
    HAL_TIM_IRQHandler(&TIM_Init);
}


