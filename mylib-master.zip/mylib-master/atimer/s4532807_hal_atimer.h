/** 
 **************************************************************
 * @file mylib/s4532807_hal_atimer.h
 * @author Linius Zaman 45328077
 * @date 27/03/2020
 * @brief mylib atimer driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_timer_init() - initialise and start atimer from zero
 * extern uint32_t s4532807_hal_atimer_timer_getms() - return atimer value
 * extern void s4532807_hal_atimer_timer_reset() - reset atimer
 * extern void s4532807_hal_atimer_timer_pause() - pause atimer
 * extern void s4532807_hal_atimer_timer_resume() - resume atimer
 * extern void s4532807_hal_atimer_clkspeed_set(int frequency) - 
 * set atimer clock speed 
 * extern void s4532807_hal_atimer_period_set(int period) - set atimer period
 * extern uint32_t s4532807_hal_atimer_timer_read(void) - 
 * read atimer counter value
 * extern void s4532807_hal_atimer_init_pin() - Init GPIO pin for atimer
 ***************************************************************
 * INTERNAL FUNCTIONS
 ***************************************************************
 * void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
 * - ISR callback function for incrementing atimerCounterVal
 * void TIM3_IRQHandler(void) - Handler for IRQ
 *************************************************************** 
 */

#ifndef s4532807_hal_atimer_h_
#define s4532807_hal_atimer_h_

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#ifdef S4532807_MYLIB_CONFIGURE_INC
#include "s4532807_hal_mylib_configure.h"
#endif

#ifndef S4532807_HAL_ATIMER_PIN 
#define S4532807_HAL_ATIMER_PIN BRD_D0_PIN
#endif

#ifndef S4532807_HAL_ATIMER_PINPORT
#define S4532807_HAL_ATIMER_PINPORT BRD_D0_GPIO_PORT
#endif

#ifndef S4532807_HAL_ATIMER_PINCLK
#define S4532807_HAL_ATIMER_PINCLK __BRD_D10_GPIO_CLK()
#endif

#ifndef S4532807_HAL_ATIMER_PERIOD
#define S4532807_HAL_ATIMER_PERIOD 1000
#endif

#ifndef S4532807_HAL_ATIMER_CLKSPEED
#define S4532807_HAL_ATIMER_CLKSPEED 50000
#endif

#define S4532807_HAL_ATIMER_TIMER_READ() s4532807_hal_atimer_timer_read() 

uint32_t atimerPrescalerVal;
uint32_t atimerCounterVal;
uint32_t atimerClkspeedVal;
uint32_t atimerPeriodVal;

/* 
 * Function initialises all the atimer variables and performs necessary setup.
 */
extern void s4532807_hal_atimer_init();

/*
 * Function initialises the atimer pin.
 */
extern void s4532807_hal_atimer_init_pin();

/*
 * Returns how many milliseconds have passed based on the period and counter.
 */
extern uint32_t s4532807_hal_atimer_timer_getms();

/*
 * Resets the atimer counter.
 */
extern void s4532807_hal_atimer_timer_reset();

/*
 * Pauses the atimer counter by preventing it from incrementing.
 * (Incrementing stops when timerRunning variable is set to 0)
 */
extern void s4532807_hal_atimer_timer_pause();

/*
 * Resumes the atimer counter by letting it increment again.
 * (Incrementing continues when timerRunning variable is set to 1)
 */
extern void s4532807_hal_atimer_timer_resume();

/*
 * This function sets the clock speed of the atimer 
 * based on the given frequency.
 */
extern void s4532807_hal_atimer_clkspeed_set();

/*
 * This function sets the period of the atimer using the value given.
 */
extern void s4532807_hal_atimer_period_set();

/*
 * This function returns the atimer counter value.
 */
extern uint32_t s4532807_hal_atimer_timer_read(void);

/*
 * Callback function for timer, increments the timer if timerRunning is set to 1
 * Toggles the pinStatus and writes to the GPIO pin
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);

/*
 * IRQ handler for timer 3, overrides default handler
 */
void TIM3_IRQHandler(void);

int timerRunning;
int pinStatus;

#endif


