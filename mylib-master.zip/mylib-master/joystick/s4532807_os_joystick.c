/** 
 **************************************************************
 * @file mylib/s4532807_os_joystick.c
 * @author Linius Zaman 45328077
 * @date 25/04/2020
 * @brief mylib joystick os driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_joystick_init(void) - init function for joystick
 * extern void s4532807_os_joystick_deinit(void) - deinit function
 * extern void JOYSTICK_Z_IRQHandler(void) - interrupt handler for Z
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_Taskjoystick_XYZ(void) - joystick read task
 */

#include "s4532807_os_joystick.h"

/*
 * This is the init function for the joystick OS library. The Z button GPIO is 
 * initialised here. Also the pin state is initialised and the time recorded 
 * (for debouncing purpose later) 
 */
extern void s4532807_os_joystick_init(void) {
        
    s4532807_hal_joystick_init(); // init hal function
    
    // semaphore for z press
    s4532807_SemaphoreJoystickZ = xSemaphoreCreateBinary();
        
    lastTick = HAL_GetTick(); // keep track of ticks for debounce
    zPinState = 0;
    
    // create task
    xTaskCreate((void *) &s4532807_Taskjoystick_XYZ, 
    (const signed char *) "OSJOYXYZ", TASKOSJOYSTICK_TASK_STACK_SIZE, NULL, 
    TASKOSJOYSTICK_PRIORITY, &s4532807_TaskJoystickXYZHandle);

    joyMsg_t joyMessage;

    // create queue
    s4532807_QueueJoystickXY = xQueueCreate(10, sizeof(joyMessage));
}

/*
 * Denitialises (deletes) the joystick Z semaphore
 */
extern void s4532807_os_joystick_deinit(void) {
    // delete task
    vTaskDelete(s4532807_TaskJoystickXYZHandle);

    // delete queue
    vQueueDelete(s4532807_QueueJoystickXY); 

    // delete semaphore
    vSemaphoreDelete(s4532807_SemaphoreJoystickZ);
}

/*
 * This is the os joystick task, it reads the joystick X and Y values using the
 * hal functions. Then writes the X and Y values to the CAG joystick.
 */
void s4532807_Taskjoystick_XYZ(void) {
    joyMsg_t writeXY;
     
    for (;;) {
        // store X and Y values from hal into struct
        writeXY.xVal = S4532807_HAL_JOYSTICK_X_READ();
        writeXY.yVal = S4532807_HAL_JOYSTICK_Y_READ();
        
        // if joystick queue exists
        if (s4532807_QueueJoystickXY != NULL) {
            // send struct to queue
            
            /*Send message to the front of the queue - wait atmost 10 ticks */
			if(xQueueSendToFront(s4532807_QueueJoystickXY, (void *) &writeXY, 
                (portTickType) 10 ) != pdPASS ) {

				portENTER_CRITICAL();
				debug_printf("Failed to post os JOYXY, after 10 ticks.\n\r");
				portEXIT_CRITICAL();
			}
            
        }
        // update every 10ms
        vTaskDelay(10);
    }
}

/* 
 * This function handles the joystick Z interrupt. It debounces the press as
 * necessary for a RISING_FALLING mode (one press per 50ms will be registered).
 * A binary semaphore is given on every interrupt, the semaphore can then be 
 * taken and the stage specific tasks controlled.
 */
extern void JOYSTICK_Z_IRQHandler(void) {

    BaseType_t xHigherPriorityTaskWoken;

    /* Is it time for another Task() to run? */
	xHigherPriorityTaskWoken = pdFALSE;

	if (s4532807_SemaphoreJoystickZ != NULL) {	// Check if semaphore exists

        // debounce
        if ((HAL_GetTick() - lastTick) >= 1000) { // reset every 1s
            zPinState = 0;
        }

        // if first RISING or FALLING interrupt, increment status
        if (zPinState == 0) {
            zPinState = 1; 

        // previously received RISING or FALLING interrupt and 50ms between the
        // two, so proceed to give semaphore
        } else if ((zPinState == 1) && (HAL_GetTick() - 50) >= lastTick) {
            // Give semaphore from ISR
		    xSemaphoreGiveFromISR(s4532807_SemaphoreJoystickZ, 
                                  &xHigherPriorityTaskWoken);
            zPinState = 0; // reset state of pin
        }

	}
	/* Perform context switching, if required. */
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
    lastTick = HAL_GetTick(); // update last tick

} 

