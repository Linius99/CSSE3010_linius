/** 
 **************************************************************
 * @file mylib/s4532807_hal_joystick.h
 * @author Linius Zaman 45328077
 * @date 30/03/2020
 * @brief mylib joystick driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern s4532807_joystick_init() - initialises the GPIO pins and ADC
 * extern int joystick_readxy() - generic function to read x or y value
 * extern int joystick_readz() - function to read z value
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) - callback for Z interrupt
 * void EXTI3_IRQHandler(void) - overrides default IRQ handler
 */

#ifndef s4532807_hal_joystick_h
#define s4532807_hal_joystick_h

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#ifdef S4532807_MYLIB_CONFIGURE_INC
#include "s4532807_hal_mylib_configure.h" 
#endif 

ADC_HandleTypeDef AdcHandleX;
ADC_HandleTypeDef AdcHandleY; 

/* 
 * This function initialises the GPIO pins and the ADC
 */
extern void s4532807_hal_joystick_init(void);

/* 
 * This function returns the X or Y value of the joystick.
 */
extern int joystick_readxy(ADC_HandleTypeDef AdcHandle);

/* 
 * This function returns the Z value of the joystick.
 */
extern int joystick_readz(void);

#define S4532807_HAL_JOYSTICK_X_READ() joystick_readxy(AdcHandleX)
#define S4532807_HAL_JOYSTICK_Y_READ() joystick_readxy(AdcHandleY)
#define S4532807_HAL_JOYSTICK_Z_READ() joystick_readz(void)

/* 
 * This is the callback function for the Z button press interrupt. It calls
 * the iss synchronise function to debounce the signal in stage2. For other
 * stages, it will call the os handler for the Z interrupt
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);

/* 
 * This function marks the interrupt handled.
 */
void EXTI3_IRQHandler(void);

#endif

