/** 
 **************************************************************
 * @file mylib/s4532807_os_joystick.h
 * @author Linius Zaman 45328077
 * @date 25/04/2020
 * @brief mylib joystick os driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_joystick_init(void) - init function for joystick
 * extern void s4532807_os_joystick_deinit(void) - deinit function
 * extern void JOYSTICK_Z_IRQHandler(void) - interrupt handler for Z
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_Taskjoystick_XYZ(void) - joystick read task
 */

#ifndef s4532807_os_joystick_h
#define s4532807_os_joystick_h

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#include "FreeRTOS.h"
#include "semphr.h"

#include "s4532807_hal_joystick.h" // to init ADC and read XY values

/* Task Priorities -----------------------------------------------------------*/
#define TASKOSJOYSTICK_PRIORITY	            ( tskIDLE_PRIORITY + 2 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKOSJOYSTICK_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )

SemaphoreHandle_t s4532807_SemaphoreJoystickZ; // semaphore for Z press
TaskHandle_t s4532807_TaskJoystickXYZHandle; // read X,Y values and Z semphr
QueueHandle_t s4532807_QueueJoystickXY; // queue to store X, Y values

typedef struct joyMsg {
    int xVal;
    int yVal;
} joyMsg_t;

unsigned int lastTick; // stores last tick (for debouncing)
unsigned int zPinState; // stores state of Z pin (for debouncing)

/*
 * This is the init function for the joystick OS library. The Z button GPIO is 
 * initialised here. Also the pin state is initialised and the time recorded 
 * (for debouncing purpose later) 
 */
extern void s4532807_os_joystick_init(void);

/*
 * Denitialises (deletes) the joystick Z semaphore
 */
extern void s4532807_os_joystick_deinit(void); 

/*
 * This is the os joystick task, it reads the joystick X and Y values using the
 * hal functions. Then writes the X and Y values to the CAG joystick queue.
 */
void s4532807_Taskjoystick_XYZ(void);

/* 
 * This function handles the joystick Z interrupt. It debounces the press as
 * necessary for a RISING_FALLING mode (one press per 50ms will be registered).
 * A binary semaphore is given on every interrupt, the semaphore can then be 
 * taken and the stage specific tasks controlled. 
 */
extern void JOYSTICK_Z_IRQHandler(void);

#endif

