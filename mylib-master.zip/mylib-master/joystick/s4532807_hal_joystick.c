/** 
 **************************************************************
 * @file mylib/s4532807_hal_joystick.c
 * @author Linius Zaman 45328077
 * @date 30/03/2020
 * @brief mylib joystick driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern s4532807_joystick_init() - initialises the GPIO pins and ADC
 * extern int joystick_readxy() - generic function to read x or y value
 * extern int joystick_readz() - function to read z value
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) - callback for Z interrupt
 * void EXTI3_IRQHandler(void) - overrides default IRQ handler
 */


#include "s4532807_hal_joystick.h"
#include "s4532807_os_joystick.h" 

#include "s4532807_os_keypad.h" // to call pushbutton interrupt handler

/* 
 * This function initialises the GPIO pins and the ADC
 */
extern void s4532807_hal_joystick_init(void) {
    ADC_ChannelConfTypeDef AdcChannelConfig;
    GPIO_InitTypeDef GPIO_InitStructure;

	__BRD_A3_GPIO_CLK();
	GPIO_InitStructure.Pin  = BRD_A3_PIN;
	GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING_FALLING;
	GPIO_InitStructure.Pull = GPIO_PULLUP;
    GPIO_InitStructure.Speed = GPIO_SPEED_FAST;
	HAL_GPIO_Init(BRD_A3_GPIO_PORT, &GPIO_InitStructure);

	HAL_NVIC_SetPriority(EXTI3_IRQn, 10, 0);
	HAL_NVIC_EnableIRQ(EXTI3_IRQn);
    
    __BRD_A1_GPIO_CLK();
    GPIO_InitStructure.Pin = BRD_A1_PIN;
    GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStructure.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(BRD_A1_GPIO_PORT, &GPIO_InitStructure);

    __BRD_A2_GPIO_CLK();
    GPIO_InitStructure.Pin = BRD_A2_PIN;
    HAL_GPIO_Init(BRD_A2_GPIO_PORT, &GPIO_InitStructure);

    __ADC1_CLK_ENABLE();
    __ADC2_CLK_ENABLE();
    AdcHandleX.Instance = (ADC_TypeDef*) ADC1_BASE;
    AdcHandleX.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV2;
    AdcHandleX.Init.Resolution = ADC_RESOLUTION12b;
    AdcHandleX.Init.ScanConvMode = DISABLE;
    AdcHandleX.Init.ContinuousConvMode = DISABLE;
    AdcHandleX.Init.DiscontinuousConvMode = DISABLE;
    AdcHandleX.Init.NbrOfDiscConversion = 0;
    AdcHandleX.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    AdcHandleX.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T1_CC1;
    AdcHandleX.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    AdcHandleX.Init.NbrOfConversion = 1;
    AdcHandleX.Init.DMAContinuousRequests = DISABLE;
    AdcHandleX.Init.EOCSelection = DISABLE;
    
    AdcHandleY = AdcHandleX;
    AdcHandleY.Instance = (ADC_TypeDef*) ADC2_BASE;

    HAL_ADC_Init(&AdcHandleX);
    HAL_ADC_Init(&AdcHandleY);

    AdcChannelConfig.Channel = BRD_A1_ADC_CHAN;
    AdcChannelConfig.Rank = 1;
    AdcChannelConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
    AdcChannelConfig.Offset = 0;
    HAL_ADC_ConfigChannel(&AdcHandleX, &AdcChannelConfig);

    AdcChannelConfig.Channel = BRD_A2_ADC_CHAN;
    HAL_ADC_ConfigChannel(&AdcHandleY, &AdcChannelConfig);
}

/* 
 * This function returns the X or Y value of the joystick.
 */
extern int joystick_readxy(ADC_HandleTypeDef AdcHandle) {
    HAL_ADC_Start(&AdcHandle);

    while (HAL_ADC_PollForConversion(&AdcHandle, 10) != HAL_OK);

    return (uint16_t) (HAL_ADC_GetValue(&AdcHandle));
}

/* 
 * This function returns the Z value of the joystick.
 */
extern int joystick_readz(void) {
    int pinStatus = HAL_GPIO_ReadPin(BRD_A3_GPIO_PORT, BRD_A3_PIN);
    if (pinStatus == 0) {
        pinStatus = 1;
    } else {
        pinStatus = 0;
    }
    return pinStatus;
}

/* 
 * This is the callback function for the Z button press interrupt. It calls
 * the iss synchronise function to debounce the signal in stage2. For other
 * stages, it will call the os handler for the Z interrupt
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if (GPIO_Pin == BRD_A3_PIN) {
        // call joystick Z interrupt handler
        JOYSTICK_Z_IRQHandler(); 
    }

    if (GPIO_Pin == BRD_USER_BUTTON_PIN) {
        // run push button interrupt handler (function in os_keypad)
        PUSHBUTTON_IRQ_HANDLER();
    }
}

/* 
 * This function marks the interrupt handled.
 */
void EXTI3_IRQHandler(void) {
	HAL_GPIO_EXTI_IRQHandler(BRD_A3_PIN);
}


