/** 
 **************************************************************
 * @file mylib/s4532807_hal_iss.h
 * @author Linius Zaman 45328077
 * @date 27/03/2020
 * @brief mylib iss driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_iss_init(void) - initialise iss
 * extern void s4532807_hal_iss_synchroniser(unsigned char signal_source);
 * - synchroniser for iss, check if signal is valid or not (above 50ms)
 * extern uint32_t s4532807_hal_iss_eventcounter_read(unsigned char 
 *                                                      signal_source_index);
 * - return event counter value for given source
 * extern uint32_t s4532807_hal_iss_lasttimer_read(unsigned char 
 *                                                      signal_source_index);
 * - return last timer value for given source
 * extern void s4532807_hal_iss_eventcounter_reset(unsigned char 
 *                                                      signal_source_index);
 * - reset event counter array for given source
 * extern void s4532807_hal_iss_lasttimer_reset(unsigned char 
 *                                                      signal_source_index);
 * - reset last timer array for given source
 * extern void s4532807_hal_iss_delaytimer_ctrl(unsigned char 
 *                                      signal_source_index, int delay_value);
 * - set delay value for given source
 *************************************************************** 
 */

#ifndef s4532807_hal_iss_h_
#define s4532807_hal_iss_h_

#include "board.h"
#include "processor_hal.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#ifdef S4532807_MYLIB_CONFIGURE_INC
#include "s4532807_hal_mylib_configure.h"
#endif

#define S4532807_HAL_ISS_SOURCE_1 0
#define S4532807_HAL_ISS_SOURCE_2 1
#define S4532807_HAL_ISS_SOURCE_3 2

uint32_t iss_eventcounter_val[3];
uint32_t iss_lasttimer_val[3];
uint32_t iss_delay_val[3];
uint32_t iss_pin_status[3];

/*
 * This function initialises the iss signal source arrays.
 */
extern void s4532807_hal_iss_init(void);

/*
 * This function synchronises (debounces) the received signal and checks for 
 * validity based on its source
 */
extern void s4532807_hal_iss_synchroniser(unsigned char signal_source);

/*
 * This function returns the event counter for the given signal source.
 */
extern uint32_t s4532807_hal_iss_eventcounter_read(unsigned char 
                                                        signal_source_index);
/*
 * This function returns the last read time for the given signal source.
 */                                                        
extern uint32_t s4532807_hal_iss_lasttimer_read(unsigned char 
                                                        signal_source_index);
/*
 * This function resets the event counter for given signal source.
 */
extern void s4532807_hal_iss_eventcounter_reset(unsigned char 
                                                        signal_source_index);
/*
 * This function resets the last timer for given signal source.
 */
extern void s4532807_hal_iss_lasttimer_reset(unsigned char 
                                                        signal_source_index);
/*
 * This function sets the delay value for the given signal source.
 */
extern void s4532807_hal_iss_delaytimer_ctrl(unsigned char signal_source_index,
                                                        int delay_value);

#endif
