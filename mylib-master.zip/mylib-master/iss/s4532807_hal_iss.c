/** 
 **************************************************************
 * @file mylib/s4532807_hal_iss.c
 * @author Linius Zaman 45328077
 * @date 27/03/2020
 * @brief mylib iss driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_iss_init(void) - initialise iss
 * extern void s4532807_hal_iss_synchroniser(unsigned char signal_source);
 * - synchroniser for iss, check if signal is valid or not (above 50ms)
 * extern uint32_t s4532807_hal_iss_eventcounter_read(unsigned char 
 *                                                      signal_source_index);
 * - return event counter value for given source
 * extern uint32_t s4532807_hal_iss_lasttimer_read(unsigned char 
 *                                                      signal_source_index);
 * - return last timer value for given source
 * extern void s4532807_hal_iss_eventcounter_reset(unsigned char 
 *                                                      signal_source_index);
 * - reset event counter array for given source
 * extern void s4532807_hal_iss_lasttimer_reset(unsigned char 
 *                                                      signal_source_index);
 * - reset last timer array for given source
 * extern void s4532807_hal_iss_delaytimer_ctrl(unsigned char 
 *                                      signal_source_index, int delay_value);
 * - set delay value for given source
 *************************************************************** 
 */

#include "s4532807_hal_iss.h"

/*
 * This function initialises the iss signal source arrays.
 */
extern void s4532807_hal_iss_init(void) {
    for (int i = 0; i < 3; i++) {
        iss_eventcounter_val[i] = 0;
        iss_lasttimer_val[i] = 0;
        iss_delay_val[i] = 0;
        iss_pin_status[i] = 0;    
    }
    iss_delay_val[2] = 50;
}

/*
 * This function synchronises (debounces) the received signal and checks for 
 * validity based on its source
 */
extern void s4532807_hal_iss_synchroniser(unsigned char signal_source_index) {
    int currentTick = HAL_GetTick();
    int lastTimerVal = iss_lasttimer_val[signal_source_index];
    int difference = currentTick - lastTimerVal;

    if (difference > 50) {
        iss_eventcounter_val[signal_source_index] += 1;
    }
    iss_lasttimer_val[signal_source_index] = currentTick;

}

/*
 * This function returns the event counter for the given signal source.
 */
extern uint32_t s4532807_hal_iss_eventcounter_read(unsigned char 
                                                    signal_source_index) {
    return iss_eventcounter_val[signal_source_index];
}

/*
 * This function returns the last read time for the given signal source.
 */  
extern uint32_t s4532807_hal_iss_lasttimer_read(unsigned char 
                                                    signal_source_index) {
    return iss_lasttimer_val[signal_source_index];
}

/*
 * This function resets the event counter for given signal source.
 */
extern void s4532807_hal_iss_eventcounter_reset(unsigned char 
                                                    signal_source_index) {
    iss_eventcounter_val[signal_source_index] = 0;
}

/*
 * This function resets the last timer for given signal source.
 */
extern void s4532807_hal_iss_lasttimer_reset(unsigned char 
                                                    signal_source_index) {
    iss_lasttimer_val[signal_source_index] = 0;
}

/*
 * This function sets the delay value for the given signal source.
 */
extern void s4532807_hal_iss_delaytimer_ctrl(unsigned char signal_source_index,
                                      int delay_value) {
    iss_delay_val[signal_source_index] = delay_value;
}

