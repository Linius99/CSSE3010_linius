/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_Display.c
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG Display driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_Display_init(void) - os init function 
 *      for CAG Display
 * extern void s4532807_os_CAG_Display_deinit(void) - os deinit function for 
 *      CAG Display
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAG_Display(void) - CAG Display task
 * void s4532807_os_CAG_Display_update_display(void) - function for printing 
 *      board to terminal using vt100 escape sequences
 * int s4532807_os_CAG_Display_get_colour(void) - function which checks display
 *      event bits to obtain colour of alive cell  
 */

#include "s4532807_os_CAG_Display.h" 
#include "s4532807_os_CAG_keypad_mnemonic.h"

// array storing the vt100 escape sequences for given colours  
char *cell_colour_palatte[] = {CELL_BLACK, CELL_RED, CELL_GREEN, CELL_YELLOW, 
                                CELL_BLUE, CELL_MAGENTA, CELL_CYAN, CELL_WHITE};

int aliveColour = BLUE; // begin with colour of stationary joystick 
int lastColour = -1; // initialise with invalid colour index

/*
 * This is the os init function for the CAG Display, it creates the task,
 * queue and event group for the CAG Display. 
 */
extern void s4532807_os_CAG_Display_init(void) {
    // create task
    xTaskCreate((void *) &s4532807_TaskCAG_Display, 
               (const signed char *) "DISP", TASKCAGDISPLAY_TASK_STACK_SIZE, 
               NULL, TASKCAGDISPLAY_PRIORITY, &s4532807_TaskCAG_DisplayHandle);

    // create queue
    s4532807_QueueCAG_Display = xQueueCreate(10, sizeof(displayBoard));
    
    // create event group
    s4532807_EventCAG_Display = xEventGroupCreate();
}

/*
 * This is the os deinit function for the CAG Display. It deletes the task,
 * queue and event group for the CAG display.
 */
extern void s4532807_os_CAG_Display_deinit(void) {
    // delete task 
    vTaskDelete(s4532807_TaskCAG_DisplayHandle);

    // delete queue
    vQueueDelete(s4532807_QueueCAG_Display);

    // delete event group
    vEventGroupDelete(s4532807_EventCAG_Display);
}

/*
 * This is the CAG Display task, it reads from the CAG display queue and if 
 * there is a new item (board to display), it updates the display by calling
 * the necessary function. The current alive colour is also obtained by calling
 * the get_colour function (which reads display colour event bits). If the 
 * alive colour has changed, the display is also updated.  
 */
void s4532807_TaskCAG_Display(void) {
    // Clear screen to begin
    portENTER_CRITICAL();
    SCREEN_CLEAR();
    portEXIT_CRITICAL();

    int lastAliveColour = YELLOW; // joystick defaults to yellow

    for (;;) {

        // Display the board in queue (queued by simulator) 
        if (s4532807_QueueCAG_Display != NULL) {

			/* Check for item received - block atmost for 10 ticks */
			if (xQueueReceive(s4532807_QueueCAG_Display, 
                              &displayBoard, 10)) {
                
                // new item in display queue, so update display    
                s4532807_os_CAG_Display_update_display();
            }        
		}

        // get current alive colour
        aliveColour = s4532807_os_CAG_Display_get_colour();

        if (lastAliveColour != aliveColour) { // update disp. if colour changed
            s4532807_os_CAG_Display_update_display();
            lastAliveColour = aliveColour;
        }
        
        /* Delay for 50ms */
		vTaskDelay(50);
	} 
}

/*
 * This function prints the board (grid) to terminal using vt100 escape
 * sequences. The colour of alive cell is obtained from the global variable 
 * aliveColour while the dead cells are always black. Cells are 4 chars wide 
 * and 2 chars high. In order to reduce time taken to print the board, the 
 * escape sequence for changing colours is only printed when the alive colour 
 * has changed. 
 */
void s4532807_os_CAG_Display_update_display(void) {
    int alive = 0; // initialise cell state

    SCREEN_HOME(); // place cursor at start
                
    for (int j = 0; j < 15; j++) {

	    for (int i = 0; i < 15; i++) {
            alive = displayBoard[i][j]; // get cell state (1 = alive, 0 = dead)

            if ((alive == 1) && (lastColour != aliveColour)) {
                debug_printf("%s    ", cell_colour_palatte[aliveColour]);
                lastColour = aliveColour; // store last printed colour
            } else if ((alive == 0) && (lastColour != BLACK)) {
                debug_printf("%s    ", cell_colour_palatte[BLACK]);
                lastColour = BLACK; // store last printed colour
            } else { // just print 4 spaces, colour unchanged
                debug_printf("    ");
            }
	    }
	    debug_printf("\n\r");
        
        /* Same loop as above repeated to achieve 2 char height */
        for (int i = 0; i < 15; i++) {
            alive = displayBoard[i][j];

            if ((alive == 1) && (lastColour != aliveColour)) {
                debug_printf("%s    ", cell_colour_palatte[aliveColour]);
                lastColour = aliveColour;
            } else if ((alive == 0) && (lastColour != BLACK)) {
                debug_printf("%s    ", cell_colour_palatte[BLACK]);
                lastColour = BLACK;
            } else { 
                debug_printf("    ");
            }
		}
        debug_printf("\n\r");
    }
}

/*
 * This function waits on the CAG display event group bits. It then iterates
 * through the event bits to see which one was set. The colour of the alive
 * cells is then updated based on the corresponding event bit. The event bit
 * is then cleared and the colour of alive cell returned (as index of cell 
 * colour pallate)
 */
int s4532807_os_CAG_Display_get_colour(void) {

    EventBits_t displayBits;

    // wait on display event bits
    displayBits = xEventGroupWaitBits(s4532807_EventCAG_Display, DISPLAY_CTRL, 
                                                           pdTRUE, pdFALSE, 10);
    
    // iterate through colours and check corresponding event bit
    for (int i = BLACK; i <= WHITE; i++) {
        if ((displayBits & (1 << i)) != 0) { // if bit was set
            aliveColour = i; // set corresponding colour
            
            // clear the bit
            displayBits = xEventGroupClearBits(s4532807_EventCAG_Display, 
                                                                      (1 << i));
            return aliveColour;
        }
    }
    		
    return aliveColour;
}
