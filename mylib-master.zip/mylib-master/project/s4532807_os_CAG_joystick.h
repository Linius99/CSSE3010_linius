/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_joystick.h
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG joystick driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_joystick_init(void) - CAG joystick init
 * extern void s4532807_os_CAG_joystick_deinit(void) - CAG joystick deinit
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAG_joystick(void) - CAG joystick task, reads X, Y and Z 
 ***************************************************************
 */

#ifndef s4532807_os_CAG_joystick_h_
#define s4532807_os_CAG_joystick_h_

/* Includes ------------------------------------------------------------------*/
#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#include "s4532807_os_joystick.h" // to access Z semaphore

#include "s4532807_os_CAG_Display.h" // to access Display event bits
#include "s4532807_os_CAG_Simulator.h" // to access Simulator event bits

/* Task Priorities -----------------------------------------------------------*/
#define TASKCAGJOYSTICK_PRIORITY	            ( tskIDLE_PRIORITY + 2 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKCAGJOYSTICK_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )

/* Private define ------------------------------------------------------------*/
TaskHandle_t s4532807_TaskCAGJoystickRead; // handle to init and deinit properly

/*
 * This is the os CAG joystick init function, it creates the CAG joystick task.
 */
extern void s4532807_os_CAG_joystick_init(void);

/*
 * This function deletes the CAG joystick task and denitialises the os joystick
 * library.
 */
extern void s4532807_os_CAG_joystick_deinit(void);

/*
 * This is the CAG joystick task, if there is a new item in the joystick X Y 
 * queue, it reads the x and y values and sets the corresponding event group
 * bits for display aliveColour or simulator updateRate. The function also 
 * attempts to take the joystick Z semaphore, if the semaphore can be taken 
 * then the simulator event bit for clear grid is also set. 
 */
void s4532807_TaskCAG_joystick(void); 

#endif
