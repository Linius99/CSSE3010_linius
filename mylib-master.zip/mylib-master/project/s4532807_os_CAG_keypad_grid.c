/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_keypad_grid.c
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG keypad grid driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_keypad_grid_init(void) - CAG keypad grid init
 * extern void s4532807_os_CAG_keypad_grid_deinit(void) - CAG keypad grid deinit
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAGKeypadGrid(void) - keypad grid task
 * void s4532807_os_CAG_keypad_grid_write_lta1000g(int subGridx, int subGridy)
 * - function which writes subgrid x and y to lta1000g queue
 */

#include "s4532807_os_CAG_keypad_grid.h"

/*
 * This function initialises the keypad grid. The onboard LEDs are intialised
 * and the Red LED turned on to signify grid mode.
 */
extern void s4532807_os_CAG_keypad_grid_init(void) {
    BRD_LEDInit(); //Initialise Board LEDs
    BRD_LEDRedOn(); // Red LED for grid mode, grid mode is default, so turn on 

    // create KEYPAD os task
    xTaskCreate((void *) &s4532807_TaskCAGKeypadGrid, 
        (const signed char *) "KEYGRID", TASKCAGKEYPADGRID_TASK_STACK_SIZE, 
        NULL, TASKCAGKEYPADGRID_PRIORITY, &s4532807_TaskKeypadGridHandle);
}

/*
 * This function is the deinit function for the keypad grid, it deletes the
 * keypad grid task.
 */
extern void s4532807_os_CAG_keypad_grid_deinit(void) {
    // delete task
    vTaskDelete(s4532807_TaskKeypadGridHandle);
}

/*
 * This is the keypad grid task. If the keypad grid semaphore can be taken then
 * it waits on the keypad event group bits to see which key was pressed then 
 * performs accordingly. Cell keys toggle cell state, 0 and F key are used to
 * select x and y subgrid values; A, B, C keys are used to start/stop/clear.
 */
void s4532807_TaskCAGKeypadGrid(void) {
    EventBits_t keyBits;
    EventBits_t simulatorBits;

    int subGridx = 0;
    int subGridy = 0;
    
    int x = 0;
    int y = 0;    

    int newMessage = 0;    
    caMessage_t sendMessage; 

    for (;;) {

        if (s4532807_SemaphoreKeypadGrid != NULL) {
            
            // see if semaphore can be obtained, try for 10 ticks
            if(xSemaphoreTake(s4532807_SemaphoreKeypadGrid, 10) == pdTRUE) {


            // wait on any of the bits to be set
            keyBits = xEventGroupWaitBits(s4532807_EventKeypadKeyPress, 
                                          EVT_KEYPAD_CTRL, pdTRUE, pdFALSE, 10);

            // see which bit was set
            if ((keyBits & EVT_0) != 0) {
                // clear bit
                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_0);
            
                subGridx++; // Increment sub-grid x
                // reached last horizontal subgrid, set it to 0 (loop back)
                if (subGridx == 5) {
                    subGridx = 0;
                }
            } else if ((keyBits & EVT_1) != 0) {
    
                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_1);
    
                // top left
                x = (subGridx * 3);
                y = (subGridy * 3);
    
                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
     
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_2) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_2);

                // top middle
                x = (subGridx * 3) + 1;
                y = (subGridy * 3);

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
 
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_3) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_3);

                // top right
                x = (subGridx * 3) + 2;
                y = (subGridy * 3);

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
 
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_4) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_4);

                // middle left
                x = (subGridx * 3);
                y = (subGridy * 3) + 1;

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
 
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_5) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_5);

                // middle middle
                x = (subGridx * 3) + 1;
                y = (subGridy * 3) + 1;

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
 
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_6) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_6);

                // middle right
                x = (subGridx * 3) + 2;
                y = (subGridy * 3) + 1;

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
 
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_7) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_7);

                // bottom left
                x = (subGridx * 3) + 0;
                y = (subGridy * 3) + 2;

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
 
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_8) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_8);

                // bottom middle
                x = (subGridx * 3) + 1;
                y = (subGridy * 3) + 2;

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
 
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_9) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_9);

                // bottom right
                x = (subGridx * 3) + 2;
                y = (subGridy * 3) + 2;

                // set up message co-ordinates
                sendMessage.cell_x = x;
                sendMessage.cell_y = y;
     
                // toggle state of cell
                if (nextBoard[x][y] == 1) {
                    // previously alive, kill it
                    sendMessage.type = 0b00010000;
                } else if (nextBoard[x][y] == 0) {
                    // previously dead, make it alive
                    sendMessage.type = 0b00010001;
                }
            
                newMessage = 1;
            } else if ((keyBits & EVT_A) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_A);

                // Start simulation
                simulatorBits = xEventGroupClearBits(
                                  s4532807_EventCAG_Simulator, START_STOP_CTRL);
        
                simulatorBits = xEventGroupSetBits(s4532807_EventCAG_Simulator, 
                                                 START_SIM);
            
            } else if ((keyBits & EVT_B) != 0) {

                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_B);

                // Stop simulation
                simulatorBits = xEventGroupClearBits(
                                  s4532807_EventCAG_Simulator, START_STOP_CTRL);

                simulatorBits = xEventGroupSetBits(s4532807_EventCAG_Simulator, 
                                                 STOP_SIM);
    
            } else if ((keyBits & EVT_C) != 0) {
                
                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_C);
    
                // Clear the display
                simulatorBits = xEventGroupSetBits(s4532807_EventCAG_Simulator, 
                                                 CLEAR_GRID);
            } else if ((keyBits & EVT_D) != 0) {
                // key not used, just clear it and do nothing
                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_D);
        
            } else if ((keyBits & EVT_E) != 0) {
                // key not used, just clear it and do nothing
                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_E);

            } else if ((keyBits & EVT_F) != 0) {
 
                keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                               EVT_F);
            
                subGridy++; // Increment sub-grid y
                // reached last vertical subgrid, set it to 0 (loop back)
                if (subGridy == 5) {
                    subGridy = 0;
                }
            }
        
            // update subgrid x and y led bits
            s4532807_os_CAG_keypad_grid_write_lta1000g(subGridx, subGridy);
    
            // if key pressed since last time struct updated, send to queue
            if (newMessage == 1) {
                // write message struct to simulator queue
                if (s4532807_QueueCAG_Simulator != NULL) {
                    if(xQueueSendToFront(s4532807_QueueCAG_Simulator, 
                        (void *) &sendMessage, (portTickType) 10 ) != pdPASS) {
    	        		portENTER_CRITICAL();
    	                debug_printf("Failed to post after 10 ticks.\n\r");
                        portEXIT_CRITICAL();
                    }            
                }
                newMessage = 0; // latest message sent, don't repeat it
            }
            }
        }
    vTaskDelay(10); // read event bits every 10ms
    }
}

/*
 * This function writes the subgrid x and y values to the lta1000g queue
 * only the corresponding x (2:0) and (5:3) y bits are updated, all other bits
 * are preserved. 
 */
void s4532807_os_CAG_keypad_grid_write_lta1000g(int subGridx, int subGridy) {
    // retrieve current value of LED bar
    uint16_t ledBitsSend = currentLEDBits;

    /* Writing subGridx and subGridy onto LED bar queue */
    
    // LED 3, 4, 5 are subGridx values 0, 1, 2 are subGridy values
    ledBitsSend = ledBitsSend & 0b0000001111000000; // zero subGrid x and y
    
    // append subGridx and subGridy values onto existing
    ledBitsSend = ledBitsSend | (subGridx << 3) | subGridy;
    
    // write to queue
    if (s4532807_QueueLta1000gWrite != NULL) {
        if(xQueueSendToFront(s4532807_QueueLta1000gWrite, (void *) &ledBitsSend, 
                             (portTickType) 10 ) != pdPASS) {
			portENTER_CRITICAL();
	        debug_printf("Failed to post after 10 ticks.\n\r");
            portEXIT_CRITICAL();
        }
    }    
}
