/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_Display.h
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG Display driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_Display_init(void) - os init function 
 *      for CAG Display
 * extern void s4532807_os_CAG_Display_deinit(void) - os deinit function for 
 *      CAG Display
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAG_Display(void) - CAG Display task
 * void s4532807_os_CAG_Display_update_display(void) - function for printing 
 *      board to terminal using vt100 escape sequences
 * int s4532807_os_CAG_Display_get_colour(void) - function which checks display
 *      event bits to obtain colour of alive cell  
 */

#ifndef s4532807_os_CAG_Display_h_
#define s4532807_os_CAG_Display_h_

/* Includes ------------------------------------------------------------------*/
#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "event_groups.h"

/* Private define ------------------------------------------------------------*/
#define EVT_BLACK   1 << 0
#define EVT_RED     1 << 1
#define EVT_GREEN   1 << 2
#define EVT_YELLOW  1 << 3
#define EVT_BLUE    1 << 4
#define EVT_MAGENTA 1 << 5
#define EVT_CYAN    1 << 6
#define EVT_WHITE   1 << 7

#define DISPLAY_CTRL 0xFF

#define SCREEN_CLEAR()  debug_printf("\e[2J")
#define SCREEN_HOME()  debug_printf("\e[H")

#define FG_BLACK 	30
#define FG_RED		31
#define FG_GREEN	32
#define FG_YELLOW	33
#define FG_BLUE		34
#define FG_MAGENTA	35
#define FG_CYAN		36
#define FG_WHITE	37
#define BG_BLACK	40
#define BG_RED		41
#define BG_GREEN	42
#define BG_YELLOW	43
#define BG_BLUE		44
#define BG_MAGENTA	45
#define BG_CYAN		46
#define BG_WHITE	47

#define CELL_BLACK "\e[7;30;40m"
#define CELL_RED	"\e[7;31;41m"
#define CELL_GREEN	"\e[7;32;42m"
#define CELL_YELLOW		"\e[7;33;43m"
#define CELL_BLUE		"\e[7;34;44m"
#define CELL_MAGENTA	"\e[7;35;45m"
#define CELL_CYAN		"\e[7;36;46m"
#define CELL_WHITE 		"\e[7;37;47m"

#define CELL_HEIGHT 4
#define CELL_WIDTH 2

#define GRID_HEIGHT 15
#define GRID_WIDTH 15

#define BLACK   0
#define RED     1
#define GREEN   2
#define YELLOW  3
#define BLUE    4
#define MAGENTA 5
#define CYAN    6
#define WHITE   7

#define SET_CELL_COLOUR(fg, bg) debug_printf("\e[7;%d;%dm",fg,bg)

/* Task Priorities -----------------------------------------------------------*/
#define TASKCAGDISPLAY_PRIORITY	            ( tskIDLE_PRIORITY + 2 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKCAGDISPLAY_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 5 )


// Handles for task, queue, event group to be able to deinit correctly
TaskHandle_t s4532807_TaskCAG_DisplayHandle;
QueueHandle_t s4532807_QueueCAG_Display;
EventGroupHandle_t s4532807_EventCAG_Display;

int displayBoard[GRID_HEIGHT][GRID_WIDTH]; 

/*
 * This is the os init function for the CAG Display, it creates the task,
 * queue and event group for the CAG Display. 
 */
extern void s4532807_os_CAG_Display_init(void);

/*
 * This is the os deinit function for the CAG Display. It deletes the task,
 * queue and event group for the CAG display.
 */
extern void s4532807_os_CAG_Display_deinit(void);

/*
 * This is the CAG Display task, it reads from the CAG display queue and if 
 * there is a new item (board to display), it updates the display by calling
 * the necessary function. The current alive colour is also obtained by calling
 * the get_colour function (which reads display colour event bits). If the 
 * alive colour has changed, the display is also updated.  
 */
void s4532807_TaskCAG_Display(void);

/*
 * This function prints the board (grid) to terminal using vt100 escape
 * sequences. The colour of alive cell is obtained from the global variable 
 * aliveColour while the dead cells are always black. Cells are 4 chars wide 
 * and 2 chars high. In order to reduce time taken to print the board, the 
 * escape sequence for changing colours is only printed when the alive colour 
 * has changed. 
 */
void s4532807_os_CAG_Display_update_display(void);

/*
 * This function waits on the CAG display event group bits. It then iterates
 * through the event bits to see which one was set. The colour of the alive
 * cells is then updated based on the corresponding event bit. The event bit
 * is then cleared and the colour of alive cell returned (as index of cell 
 * colour pallate)
 */
int s4532807_os_CAG_Display_get_colour(void);

#endif
