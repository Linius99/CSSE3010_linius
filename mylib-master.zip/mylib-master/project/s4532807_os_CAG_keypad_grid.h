/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_keypad_grid.h
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG keypad grid driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_keypad_grid_init(void) - CAG keypad grid init
 * extern void s4532807_os_CAG_keypad_grid_deinit(void) - CAG keypad grid deinit
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAGKeypadGrid(void) - keypad grid task
 * void s4532807_os_CAG_keypad_grid_write_lta1000g(int subGridx, int subGridy)
 * - function which writes subgrid x and y to lta1000g queue
 */

#ifndef s4532807_os_CAG_keypad_grid_h_
#define s4532807_os_CAG_keypad_grid_h_

/* Task Priorities -----------------------------------------------------------*/
#define TASKCAGKEYPADGRID_PRIORITY	            ( tskIDLE_PRIORITY + 2 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKCAGKEYPADGRID_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "event_groups.h"
#include "semphr.h"

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#include "s4532807_os_keypad.h" // to access Key press event bits
#include "s4532807_os_lta1000g.h" // to access current LED bar values
#include "s4532807_os_CAG_Simulator.h" // to draw cell and start/stop simulation

TaskHandle_t s4532807_TaskKeypadGridHandle;

/*
 * This function initialises the keypad grid. The onboard LEDs are intialised
 * and the Red LED turned on to signify grid mode.
 */
extern void s4532807_os_CAG_keypad_grid_init(void);

/*
 * This function is the deinit function for the keypad grid, it deletes the
 * keypad grid task.
 */
extern void s4532807_os_CAG_keypad_grid_deinit(void);

/*
 * This is the keypad grid task. If the keypad grid semaphore can be taken then
 * it waits on the keypad event group bits to see which key was pressed then 
 * performs accordingly. Cell keys toggle cell state, 0 and F key are used to
 * select x and y subgrid values; A, B, C keys are used to start/stop/clear.
 */
void s4532807_TaskCAGKeypadGrid(void);

/*
 * This function writes the subgrid x and y values to the lta1000g queue
 * only the corresponding x (2:0) and (5:3) y bits are updated, all other bits
 * are preserved. 
 */
void s4532807_os_CAG_keypad_grid_write_lta1000g(int subGridx, int subGridy);

#endif
