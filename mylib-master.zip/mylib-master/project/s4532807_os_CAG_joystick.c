/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_joystick.c
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG joystick driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_joystick_init(void) - CAG joystick init
 * extern void s4532807_os_CAG_joystick_deinit(void) - CAG joystick deinit
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAG_joystick(void) - CAG joystick task, reads X, Y and Z 
 ***************************************************************
 */

#include "s4532807_os_CAG_joystick.h"

/*
 * This is the os CAG joystick init function, it creates the CAG joystick task.
 */
extern void s4532807_os_CAG_joystick_init(void) {
    // create task
    xTaskCreate((void *) &s4532807_TaskCAG_joystick, 
          (const signed char *) "CAGJOY", TASKCAGJOYSTICK_TASK_STACK_SIZE, NULL, 
          TASKCAGJOYSTICK_PRIORITY, &s4532807_TaskCAGJoystickRead);    
}

/*
 * This function deletes the CAG joystick task and denitialises the os joystick
 * library.
 */
extern void s4532807_os_CAG_joystick_deinit(void) {
    // deinit the os joystick library
    s4532807_os_joystick_deinit();
    
    // delete task
    vTaskDelete(s4532807_TaskCAGJoystickRead);
} 

/*
 * This is the CAG joystick task, if there is a new item in the joystick X Y 
 * queue, it reads the x and y values and sets the corresponding event group
 * bits for display aliveColour or simulator updateRate. The function also 
 * attempts to take the joystick Z semaphore, if the semaphore can be taken 
 * then the simulator event bit for clear grid is also set. 
 */
void s4532807_TaskCAG_joystick(void) {
    joyMsg_t readXY;

    EventBits_t displayBits;
    EventBits_t simulatorBits;

    for (;;) {
                
        if (s4532807_QueueJoystickXY != NULL) {	/* Check if queue exists */

			/* Check for item received - block atmost for 10 ticks */
		    if (xQueueReceive(s4532807_QueueJoystickXY, &readXY, 10)) {
                             
                // clear all display COLOUR bits
                displayBits = xEventGroupClearBits(s4532807_EventCAG_Display, 
                                                    DISPLAY_CTRL);

                // change display colour using event bits
                if ((readXY.xVal >= 0) && (readXY.xVal <= 512)) {
                    // black
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_BLACK);
                } else if ((readXY.xVal >= 512) && (readXY.xVal <= 1024)) {
                    // red
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_RED);
                } else if ((readXY.xVal >= 1024) && (readXY.xVal <= 1536)) {
                    // green
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_GREEN);                
                } else if ((readXY.xVal >= 1536) && (readXY.xVal <= 2048)) {
                    // yellow
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_YELLOW);
                } else if ((readXY.xVal >= 2048) && (readXY.xVal <= 2560)) {
                   // blue
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_BLUE);
                } else if ((readXY.xVal >= 2560) && (readXY.xVal <= 3072)) {
                    // magenta
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_MAGENTA);
                } else if ((readXY.xVal >= 3072) && (readXY.xVal <= 3584)) {
                    // cyan
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_CYAN);
                } else if ((readXY.xVal >= 3584) && (readXY.xVal <= 4096)) {
                    // white
                    displayBits = xEventGroupSetBits(s4532807_EventCAG_Display, 
                                                     EVT_WHITE);
                }               

                simulatorBits = xEventGroupClearBits(
                                s4532807_EventCAG_Simulator, UPD_CTRL);

                // change simulation speed using event bits
                if (readXY.yVal <= 820) {
                    // 0.5s
                    simulatorBits = xEventGroupSetBits(
                                      s4532807_EventCAG_Simulator, UPD_HALFSEC);
                } else if (readXY.yVal <= 1640) {
                    // 1s
                    simulatorBits = xEventGroupSetBits(
                                       s4532807_EventCAG_Simulator, UPD_ONESEC);
                } else if (readXY.yVal <= 2460) {
                    // 2s                
                    simulatorBits = xEventGroupSetBits(
                                       s4532807_EventCAG_Simulator, UPD_TWOSEC);
                } else if (readXY.yVal <= 3280) {
                    // 5s
                    simulatorBits = xEventGroupSetBits(
                                      s4532807_EventCAG_Simulator, UPD_FIVESEC); 
                } else if (readXY.yVal <= 4096) {
                    // 10s
                    simulatorBits = xEventGroupSetBits(
                                       s4532807_EventCAG_Simulator, UPD_TENSEC);
                }     
        	}
		}        

        if (s4532807_SemaphoreJoystickZ != NULL) { // check semaphore exists
            
            // see if semaphore can be obtained, try for 10 ticks
            if(xSemaphoreTake(s4532807_SemaphoreJoystickZ, 10) == pdTRUE) { 
                // semaphore obtained, set clear bit for simulator
                simulatorBits = xEventGroupSetBits(s4532807_EventCAG_Simulator, 
                                                 CLEAR_GRID);
            }
        }
        // update every ms
        vTaskDelay(1);
    }
} 
