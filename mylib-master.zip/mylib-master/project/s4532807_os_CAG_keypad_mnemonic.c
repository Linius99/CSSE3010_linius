/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_keypad_mnemonic.c
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG keypad mnemonic driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_keypad_mnemonic_init(void) - init mnemonic mode
 * extern void s4532807_os_CAG_keypad_mnemonic_deinit(void) - deinit mnemonic
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAGKeypadMnemonic(void) - keypad mnemonic task, runs FSM 
 * void s4532807_os_CAG_keypad_mnemonic_clear_buffer(void) - clear keysPressed
 *      buffer
 * void s4532807_os_CAG_keypad_mnemonic_init_states(void) - initialise the state
 *      of the commands
 * int s4532807_os_CAG_keypad_mnemonic_check_for_command(void) - check buffer
 *      for every possible 13, 11 or 8 char commads
 * int s4532807_os_CAG_keypad_mnemonic_check_8_for_command(void) - check chars
 *      for an 8 char command
 * char s4532807_os_CAG_keypad_mnemonic_get_key(void) - gets pressed key
 * void s4532807_os_CAG_keypad_mnemonic_command_state(void) - FSM COMMAND_STATE 
 * void s4532807_os_CAG_keypad_mnemonic_type_state(void) - FSM TYPE_STATE
 * void s4532807_os_CAG_keypad_mnemonic_xval_state(void) - FSM XVAL_STATE
 * void s4532807_os_CAG_keypad_mnemonic_yval_state(void) - FSM YVAL_STATE
 * void s4532807_os_CAG_keypad_mnemonic_write_state(void) - FSM WRITE_STATE
 */

#include "s4532807_os_CAG_keypad_mnemonic.h"

#include "s4532807_os_CAG_Display.h"


int numPresses = 0; // keep track of number of presses

caMessage_t mnemonicMessage; 

/* Command strings to check inputs against */
char charsSTL[12] = {'7','7','7','7','7','8','8','5','5','5','5','\0'};
char charsOSC[14] = {'6','6','6','6','7','7','7','7','7','2','2','2','2','\0'};
char charsGLD[9] = {'4','4','5','5','5','5','3','3','\0'};
char charsDLT[9] = {'3','3','5','5','5','5','8','8','\0'};
char charsCRE[12] = {'2','2','2','2','7','7','7','7','3','3','3','\0'};

/* Flags for each command */
bool stateSTL = false;
bool stateOSC = false;
bool stateGLD = false;
bool stateDLT = false;
bool stateCRE = false;

int mnemonicState = COMMAND_STATE; // begin mnemomnic FSM with COMMAND_STATE

/*
 * This function creates the keypad mnemonic task and initialises the keys
 * pressed buffer.
 */
extern void s4532807_os_CAG_keypad_mnemonic_init(void) {
    // create KEYPAD mnemonic task
    xTaskCreate((void *) &s4532807_TaskCAGKeypadMnemonic, 
        (const signed char *) "KEYMNEM", TASKCAGKEYMNEMONIC_TASK_STACK_SIZE, 
        NULL, TASKCAGKEYMNEMONIC_PRIORITY, &s4532807_TaskKeypadMnemonicHandle);

    // initialise keysPressed buffer
    s4532807_os_CAG_keypad_mnemonic_clear_buffer();
}

/*
 * This function deletes the keypad mnemonic task.
 */
extern void s4532807_os_CAG_keypad_mnemonic_deinit(void) {
    // delete task
    vTaskDelete(s4532807_TaskKeypadMnemonicHandle);
}

/*
 * This is the keypad mnemonic task, if the mnemonic mode semaphore can be
 * obtained, then it processes the mnemonic FSM. The FSM has states COMMAND,
 * TYPE, XVAL YVAL and WRITE.
 */
void s4532807_TaskCAGKeypadMnemonic(void) {

    for (;;) {
        if (s4532807_SemaphoreKeypadMnemonic != NULL) {
            
            // see if semaphore can be obtained, try for 10 ticks
            if(xSemaphoreTake(s4532807_SemaphoreKeypadMnemonic, 10) == pdTRUE) { 

                if (mnemonicState == COMMAND_STATE) {
                    s4532807_os_CAG_keypad_mnemonic_command_state();
                } else if (mnemonicState == TYPE_STATE) {
                    s4532807_os_CAG_keypad_mnemonic_type_state();
                } else if (mnemonicState == XVAL_STATE) {
                    s4532807_os_CAG_keypad_mnemonic_xval_state();
                } else if (mnemonicState == YVAL_STATE) {
                    s4532807_os_CAG_keypad_mnemonic_yval_state();
                } else if (mnemonicState == WRITE_STATE) {
                    s4532807_os_CAG_keypad_mnemonic_write_state();
                } 
            }
        }
        vTaskDelay(10);    
    }
}

/*
 * This function sets all of the chars of the keysPressed buffer to an unused
 * character, so once a valid command is received, we can call this function 
 * to ensure the command will not be acted upon again.
 */
void s4532807_os_CAG_keypad_mnemonic_clear_buffer(void) {
    for (int i = 0; i < BUFFER_SIZE; i++) {
        keysPressed[i] = 'Z'; // initialise with Z, unused character
    }    
}

/*
 * This is the command state function of the mnemonic FSM. If 0, D or F keys
 * are pressed then the simulator bit for clear, stop and start will be set 
 * respectively. If any other char is pressed and enough characters are present
 * in the buffer, then function to check the buffer for commands will be called.
 */
void s4532807_os_CAG_keypad_mnemonic_command_state(void) {
    char lastKey = 'Z';
    EventBits_t simulatorBits;
    lastKey = s4532807_os_CAG_keypad_mnemonic_get_key();
        
    if ((lastKey == '0') && (mnemonicState == COMMAND_STATE)) {
        // clear screen
        simulatorBits = xEventGroupSetBits(s4532807_EventCAG_Simulator, 
                                                 CLEAR_GRID);
    } else if (lastKey == 'D') {
        // stop simulation
        simulatorBits = xEventGroupClearBits(s4532807_EventCAG_Simulator, 
                                                 START_STOP_CTRL);

        simulatorBits = xEventGroupSetBits(s4532807_EventCAG_Simulator, 
                                                 STOP_SIM);
    } else if (lastKey == 'F') {
        // start simulation
        simulatorBits = xEventGroupClearBits(s4532807_EventCAG_Simulator, 
                                                 START_STOP_CTRL);

        simulatorBits = xEventGroupSetBits(s4532807_EventCAG_Simulator, 
                                                 START_SIM);
    }

    if ((numPresses > 8) && (mnemonicState == COMMAND_STATE)) {
        // there are more than 8 chars in buffer, which means we have to check
        // for 8, 11 or 13 char commands. 8 or 11 char commands require cycling
        // through consecutive 8 and 11 chars within a larger string of chars
        // call below function to perform this
        s4532807_os_CAG_keypad_mnemonic_check_for_command();
    } else if ((numPresses == 8) && (mnemonicState == COMMAND_STATE)) {
        // only 8 chars entered, check the GLD and DLT commands
        s4532807_os_CAG_keypad_mnemonic_check_8_for_command();
    }    
}

/*
 * This function handles the TYPE_STATE of the mnemonicFSM. If the command was
 * DLT or CRE then the next key will lead to the corresponding driver being 
 * deleted (deinit) or created (init). If the command was STL, or OSC then the
 * next key determines what type of lifeform to draw, then the FSM proceeds to
 * the XVAL_STATE. If the command was GLD then we simply begin a 
 * mnemonicMessage of type spaceship and proceed to the XVAL_STATE. If no key is
 * pressed remain in TYPE_STATE or go back to COMMAND_STATE if invalid key is 
 * pressed.
 */
void s4532807_os_CAG_keypad_mnemonic_type_state(void) {
    char typeKey = 'Z';

    typeKey = s4532807_os_CAG_keypad_mnemonic_get_key();

    if (mnemonicState == TYPE_STATE) {
        if (stateSTL == true) {            
            // STL 0 block 1 beehive 2 loaf
            if (typeKey == '0') {
                mnemonicMessage.type = 0b00100000;
                mnemonicState = XVAL_STATE;
            } else if (typeKey == '1') {
                mnemonicMessage.type = 0b00100001;
                mnemonicState = XVAL_STATE;
            } else if (typeKey == '2') {
                mnemonicMessage.type = 0b00100010;
                mnemonicState = XVAL_STATE;
            } else if (typeKey == 'Z') {
                // no key pressed yet, do nothing
            } else if (typeKey != 'Z') {
                // invalid key pressed
                mnemonicState = COMMAND_STATE;
            }
        } else if (stateOSC == true) {
            // OSC 0 blinker 1 toad 2 beacon
            if (typeKey == '0') {
                mnemonicMessage.type = 0b00110000;
                mnemonicState = XVAL_STATE;
            } else if (typeKey == '1') {
                mnemonicMessage.type = 0b00110001;
                mnemonicState = XVAL_STATE;
            } else if (typeKey == '2') {
                mnemonicMessage.type = 0b00110010;
                mnemonicState = XVAL_STATE;
            } else if (typeKey == 'Z') {
                // no key pressed yet, do nothing
            } else if (typeKey != 'Z') {
                // invalid key pressed
                mnemonicState = COMMAND_STATE;
            }
        } else if (stateDLT == true) {
            // DLT 0 simulator 1 joystick
            if (typeKey == '0') {
                // deinit simulator
                s4532807_os_CAG_Simulator_deinit();
                s4532807_os_CAG_keypad_mnemonic_clear_buffer();
                mnemonicState = COMMAND_STATE;
            } else if (typeKey == '1') {
                // deinit joystick
                s4532807_os_CAG_joystick_deinit(); 
                s4532807_os_CAG_keypad_mnemonic_clear_buffer();
                mnemonicState = COMMAND_STATE;
            } else if (typeKey == 'Z') {
                // no key pressed yet, do nothing
            } else if (typeKey != 'Z') {
                // invalid key pressed
                mnemonicState = COMMAND_STATE;
            }
        } else if (stateCRE == true) {
            // CRE 0 simulator 1 joystick
            if (typeKey == '0') {
                // init simulator
                s4532807_os_CAG_Simulator_init();
                s4532807_os_CAG_keypad_mnemonic_clear_buffer();
                mnemonicState = COMMAND_STATE;
            } else if (typeKey == '1') {
                // init joystick
                s4532807_os_CAG_joystick_init(); 
                s4532807_os_CAG_keypad_mnemonic_clear_buffer();
                mnemonicState = COMMAND_STATE;
            } else if (typeKey == 'Z') {
               // no key pressed yet, do nothing
            } else if (typeKey != 'Z') {
                // invalid key pressed
                mnemonicState = COMMAND_STATE;
            }
        } else if (stateGLD == true) {
            // no key pressed, don't need a press, begin glider message
            mnemonicMessage.type = 0b01000000;
            mnemonicState = XVAL_STATE;
        }
    }
}

/*
 * This function handles the XVAL_STATE of the mnemonic FSM. It reads which key
 * was pressed (if any), if the key is a valid subgrid key (0->4), then the 
 * appropriate cell_x value is set in the mnemonicMessage. Then the FSM proceeds 
 * to the YVAL_STATE. If no key was pressed then remains in XVAL_STATE. If an
 * invalid key is pressed, goes back to COMMAND_STATE.
 */
void s4532807_os_CAG_keypad_mnemonic_xval_state(void) {
    char xKey = 'Z';

    xKey = s4532807_os_CAG_keypad_mnemonic_get_key();

    if (mnemonicState == XVAL_STATE) {
        if (xKey == 'Z') { // nothing entered yet
            // do nothing
        } else if (xKey == '0') {
            mnemonicMessage.cell_x = 0;
            mnemonicState = YVAL_STATE;
        } else if (xKey == '1') {
            mnemonicMessage.cell_x = 3;
            mnemonicState = YVAL_STATE;
        } else if (xKey == '2') {
            mnemonicMessage.cell_x = 6;
            mnemonicState = YVAL_STATE;
        } else if (xKey == '3') {
            mnemonicMessage.cell_x = 9;
            mnemonicState = YVAL_STATE;
        } else if (xKey == '4') {
            mnemonicMessage.cell_x = 12;
            mnemonicState = YVAL_STATE;    
        } else if (xKey != 'Z') { // invalid key entered
            mnemonicState = COMMAND_STATE;        
        }
    }
}

/*
 * This function handles the YVAL_STATE of the mnemonic FSM. It reads which key
 * was pressed (if any), if the key is a valid subgrid key (0->4), then the 
 * appropriate cell_y value is set in the mnemonicMessage. Then the FSM proceeds 
 * to the WRITE_STATE. If no key was pressed then remains in YVAL_STATE. If an
 * invalid key is pressed, goes back to COMMAND_STATE.
 */
void s4532807_os_CAG_keypad_mnemonic_yval_state(void) {
    char yKey = 'Z';

    yKey = s4532807_os_CAG_keypad_mnemonic_get_key();

    if (mnemonicState == YVAL_STATE) {
        if (yKey == 'Z') { // nothing entered yet
            // do nothing
        } else if (yKey == '0') {
            mnemonicMessage.cell_y = 0;
            mnemonicState = WRITE_STATE;
            s4532807_os_CAG_keypad_mnemonic_write_state();
        } else if (yKey == '1') {
            mnemonicMessage.cell_y = 3;
            mnemonicState = WRITE_STATE;
            s4532807_os_CAG_keypad_mnemonic_write_state();
        } else if (yKey == '2') {
            mnemonicMessage.cell_y = 6;
            mnemonicState = WRITE_STATE;
            s4532807_os_CAG_keypad_mnemonic_write_state();
        } else if (yKey == '3') {
            mnemonicMessage.cell_y = 9;
            mnemonicState = WRITE_STATE;
            s4532807_os_CAG_keypad_mnemonic_write_state();
        } else if (yKey == '4') {
            mnemonicMessage.cell_y = 12;
            mnemonicState = WRITE_STATE;   
            s4532807_os_CAG_keypad_mnemonic_write_state();
        } else if (yKey != 'Z') { // invalid key entered
            mnemonicState = COMMAND_STATE;        
        }
    }
}

/*
 * This function processes the WRITE_STATE of the mnemonic FSM. By the time
 * we reach this state, the mnemonicMessage struct has all the necessary fields
 * complete for the simulator queue, so this function writes to the the queue,
 * deletes the command chars from the buffer and sets the menmonic FSM state to
 * command state to continue receiving commands.
 */
void s4532807_os_CAG_keypad_mnemonic_write_state(void) {
    if (mnemonicState == WRITE_STATE) {
        // writing to simulator
        if ((s4532807_QueueCAG_Simulator != NULL)) {
 
            /*Send message to the front of the queue - wait atmost 10 ticks */
			if(xQueueSendToFront(s4532807_QueueCAG_Simulator, 
                (void *) &mnemonicMessage, (portTickType) 10 ) != pdPASS) {

    	        portENTER_CRITICAL();
		        debug_printf("Failed to post after 10 ticks.\n\r");
		        portEXIT_CRITICAL();
	        } else {
                // written successfully to simulator queue
                // delete command from buffer (so it isn't drawn again)
                s4532807_os_CAG_keypad_mnemonic_clear_buffer();
                // back to command state
                mnemonicState = COMMAND_STATE;
            }                
        }
    }
}

/*
 * This function sets the state of all commands to false.
 */
void s4532807_os_CAG_keypad_mnemonic_init_states(void) {
    stateSTL = false;
    stateOSC = false;
    stateGLD = false;
    stateDLT = false;
    stateCRE = false;
}

/*
 * This function checks the currently stored 13 characters against all of the 
 * possible commands (13, 11, and 8 char long) to check if a valid command has 
 * been entered. If so, the state is updated accordingly, otherwise remain in
 * in command state. If any valid command is found, then the return value is 1,
 * otherwise the return value is 0.  
 */
int s4532807_os_CAG_keypad_mnemonic_check_for_command(void) {
    /* If there are 13 chars in the buffer, check for match with OSC command */
    if (numPresses >= BUFFER_SIZE) { 
        // compare with charsOSC
        if (strncmp(keysPressed, charsOSC, 13) == 0) { // matched charsOSC
            mnemonicState = TYPE_STATE; // proceed to type state
            s4532807_os_CAG_keypad_mnemonic_init_states(); 
            stateOSC = true;
            return 1; // match found with OSC            
        }
    }

    int numChars = 0;
    char bufferEight[8] = {'\0'}; // buffer to hold 8 char strings (GLD/DLT)
    char bufferEleven[11] = {'\0'}; // buffer to hold 11 char strings (STL/CRE)

    /* The following nested loops are used to store every 8 or 11 char segment 
     * within the keysPressed buffer into a new buffer (bufferEight or 
     * bufferEleven), the buffers are then checked against the 8 or 11 char 
     * commands. If a match is found, the mnemonic FSM state is changed to TYPE
     * STATE (unless GLD, then proceed to XVAL_STATE).  
     * the 8 and 11 char buffers are overwritten in every iteration
     */
    for (int k = 0; k < 4; k++) { // check 8 + k char segments, thus the k loop

        // the j value determines the offset from index 0 of keysPressed buffer
        for (int j = 0; j <= (BUFFER_SIZE - (8 + k)); j++) {

            // i is used as index of the buffers; (keysPressed buffer uses i+j)
            for (int i = 0; i < (8 + k); i++) {
                // check which buffer to use
                if ((k + 8) == 8) {
                    bufferEight[i] = keysPressed[i+j]; // copy chars to buffer
                    numChars = i + 1; // increment numChars
                } else if ((k + 8) == 11) {
                    bufferEleven[i] = keysPressed[i+j];
                    numChars = i + 1;
                }
            }
            // bufferEight or bufferEleven is now complete

            // check for matches with 8 or 11 letter commands (ignore 9 and 10)
            if (numChars == 8) {
                if (strncmp(bufferEight, charsGLD, 8) == 0) { // GLD
                    s4532807_os_CAG_keypad_mnemonic_init_states();
                    stateGLD = true;
                    mnemonicMessage.type = 0b01000000;
                    mnemonicState = XVAL_STATE; // no type needed, go to xval
                    return 1;
                } else if (strncmp(bufferEight, charsDLT, 8) == 0) { // DLT
                    mnemonicState = TYPE_STATE; // proceed to type state
                    s4532807_os_CAG_keypad_mnemonic_init_states();
                    stateDLT = true;
                    return 1;
                }
            } else if (numChars == 11) {
                if (strncmp(bufferEleven, charsSTL, 11) == 0) { // STL
                    mnemonicState = TYPE_STATE; // proceed to type state
                    s4532807_os_CAG_keypad_mnemonic_init_states();
                    stateSTL = true;
                    return 1;
                } else if (strncmp(bufferEleven, charsCRE, 11) == 0) { // CRE
                    mnemonicState = TYPE_STATE; // proceed to type state
                    s4532807_os_CAG_keypad_mnemonic_init_states();
                    stateCRE = true;
                    return 1;
                }                
            }
            numChars = 0;
        }
    }

    return 0; // no matches found
}

/*
 * If only 8 keys have been pressed, we don't use the sliding function, we can
 * simply compare the currently stored 8 characters to the 8 char commands
 * and see if it is a valid command. If a valid command was entered, the state
 * will be updated accordingly, otherwise we stay in command state. If valid 8
 * char command is found, 1 will be returned, else 0 is returned.
 */
int s4532807_os_CAG_keypad_mnemonic_check_8_for_command(void) {
    char bufferEight[8];

    for (int i = 0; i < 8; i++) { // 0->7
        bufferEight[i] = keysPressed[i];
    }

    if (strncmp(bufferEight, charsGLD, 8) == 0) { // matched charsGLD
        s4532807_os_CAG_keypad_mnemonic_init_states();
        stateGLD = true;
        mnemonicMessage.type = 0b01000000;
        mnemonicState = XVAL_STATE; // no type needed, straight to xval
        return 1;
    } else if (strncmp(bufferEight, charsDLT, 8) == 0) { // matched charsDLT
        mnemonicState = TYPE_STATE;
        s4532807_os_CAG_keypad_mnemonic_init_states();
        stateDLT = true;
        return 1;
    } 
}

/*
 * This function waits on the key press event group bits. Gets which key was
 * pressed and stores it to a buffer of up to 13 characters. If 13 presses have 
 * occured, every next press removes the oldest character and the latest key is 
 * stored in the latest index. The pressed key is returned as a char, if no key
 * was pressed, the char 'Z' is returned instead.
 */
char s4532807_os_CAG_keypad_mnemonic_get_key(void) {
    
    EventBits_t mnemonicBits;
    char key = 'Z'; // initialise with unused char
    char backupKeys[13];

    // wait on keypad event bits
    mnemonicBits = xEventGroupWaitBits(s4532807_EventKeypadKeyPress, 
                                       EVT_KEYPAD_CTRL, pdTRUE, pdFALSE, 10);
    
    // iterate through key events and check corresponding event bit
    for (int i = 0; i <= 15; i++) {
        if ((mnemonicBits & (1 << i)) != 0) { // if bit was set
            // clear the bit
            mnemonicBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                                                      (1 << i));
            if (i == 0) {
                key = '0';
            } else if (i == 1) {
                key = '1';
            } else if (i == 2) {
                key = '2';
            } else if (i == 3) {
                key = '3';
            } else if (i == 4) {
                key = '4';
            } else if (i == 5) {
                key = '5';
            } else if (i == 6) {
                key = '6';
            } else if (i == 7) {
                key = '7';
            } else if (i == 8) {
                key = '8';
            } else if (i == 9) {
                key = '9';
            } else if (i == 10) {
                key = 'A';
            } else if (i == 11) {
                key = 'B';
            } else if (i == 12) {
                key = 'C';
            } else if (i == 13) {
                key = 'D';
            } else if (i == 14) {
                key = 'E';
            } else if (i == 15) {
                key = 'F';
            }

            numPresses++;
            
            if (numPresses <= 13) {
                keysPressed[numPresses - 1] = key;
            } else if (numPresses > 13) {

                for (int i = 0; i < 12; i++) { // remove oldest char
                    backupKeys[i] = keysPressed[i+1]; // move index by 1 to left
                }
                
                backupKeys[12] = key; // store key just pressed at latest index
                
                for (int i = 0; i < 13; i++) { 
                    keysPressed[i] = backupKeys[i];
                }
            }
            return key;
        }
    }
    		
    return key; 
}
