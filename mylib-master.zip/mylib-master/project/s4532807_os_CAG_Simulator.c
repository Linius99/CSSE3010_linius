/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_Simulator.c
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG Simulator driver
 *        Ref: https://processing.org/examples/gameoflife.html CGoL simulation
 *             algorithm was derived from this website, used in function
 *             s4532807_os_CAG_Simulator_simulate();
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_os_CAG_Simulator_init(void) - CAG Simulator init
 * void s4532807_os_CAG_Simulator_deinit(void) - CAG Simulator deinit
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAG_Simulator(void) - CAG Simulator task
 * void s4532807_os_CAG_Simulator_write_to_display(void) - writes to disp. queue
 * int s4532807_os_CAG_Simulator_get_clear_bit(void) - waits on clear event bit
 * int s4532807_os_CAG_Simulator_get_simulator_state(void) - waits on start/stop
 * int s4532807_os_CAG_Simulator_get_update_time(void) - waits on update bits
 * void s4532807_os_CAG_Simulator_draw_from_message(caMessage_t message) - 
 * parses a caMessage and calls necessary functions to draw it
 * void s4532807_os_CAG_Simulator_clear_board(void) - clears board
 * void s4532807_os_CAG_Simulator_draw_cell(int x, int y) - draws an alive cell
 * void s4532807_os_CAG_Simulator_kill_cell(int x, int y) - kills cell
 * void s4532807_os_CAG_Simulator_draw_block(int x, int y) - draws block
 * void s4532807_os_CAG_Simulator_draw_beehive(int x, int y) - draws beehive
 * void s4532807_os_CAG_Simulator_draw_loaf(int x, int y) - draws loaf
 * void s4532807_os_CAG_Simulator_draw_blinker(int x, int y) - draws blinker
 * void s4532807_os_CAG_Simulator_draw_beacon(int x, int y) - draws beacon
 * void s4532807_os_CAG_Simulator_draw_glider(int x, int y) - draws glider
 * void s4532807_os_CAG_Simulator_draw_toad(int x, int y) - draws toad
 ***************************************************************
 */


#include "s4532807_os_CAG_Simulator.h"

/*
 * Simulator os init function; creates task, queue and event group for the 
 * CAG Simulator.
 */
extern void s4532807_os_CAG_Simulator_init(void) {
    // create task
    xTaskCreate((void *) &s4532807_TaskCAG_Simulator, 
            (const signed char *) "SIM", TASKCAGSIMULATOR_TASK_STACK_SIZE, 
            NULL, TASKCAGSIMULATOR_PRIORITY, &s4532807_TaskCAG_SimulatorHandle);

    caMessage_t simulatorMessage; // create message struct

    // create queue
    s4532807_QueueCAG_Simulator = xQueueCreate(10, sizeof(simulatorMessage));
    
    // create event group
    s4532807_EventCAG_Simulator = xEventGroupCreate();
}

/*
 * Simulator deinit function; deletes task, queue and event group for the 
 * CAG Simulator.
 */
extern void s4532807_os_CAG_Simulator_deinit(void) {
    // delete task 
    vTaskDelete(s4532807_TaskCAG_SimulatorHandle);

    // delete queue
    vQueueDelete(s4532807_QueueCAG_Simulator);

    // delete event group
    vEventGroupDelete(s4532807_EventCAG_Simulator);
}

/*
 * This is the CAG Simulator task, it checks the simulator queue for cells or
 * lifeforms to draw. If something is to be drawn, it calls the necessary 
 * function to parse the message and draw on the board. It then writes the 
 * board to the display queue. If the duration of the updateRate has elapsed, 
 * then it calls the CGoL simulation on the board, then writes the board to the 
 * display queue. Functions which check the simulator updateRate, start, stop 
 * and clear bits are also called and the task performs as necessary.
 */
void s4532807_TaskCAG_Simulator(void) {

    caMessage_t receivedMessage; // struct to receive messages

    int clearBit = 0; // initialise clear bit of
    int simulatorState = STATE_RUNNING; // init. simulator state (start/stop)
    int updateRate = 1000; // init update rate (milliseconds)

    // store tick to apply simulation frequency (updateRate)
    int lastTick = 0;
    int currentTick = 0;

    s4532807_os_CAG_Simulator_clear_board(); // clear board
    s4532807_os_CAG_Simulator_write_to_display(); // send empty board to disp.

    for (;;) {
        
        // check CAG simulator queue for cell/lifeform to draw
        if (s4532807_QueueCAG_Simulator != NULL) {	/* Check if queue exists */

			/* Check for item received - block atmost for 10 ticks */
			if (xQueueReceive(s4532807_QueueCAG_Simulator, 
                              &receivedMessage, 10)) {
                
                // call function to parse message and draw cell/lifeform
                s4532807_os_CAG_Simulator_draw_from_message(receivedMessage);
                // send to display queue
                s4532807_os_CAG_Simulator_write_to_display();
            }
        }
        
        // check clear bit of simulator event bits
        clearBit = s4532807_os_CAG_Simulator_get_clear_bit();

        // clear the board if bit was set
        if (clearBit == 1) {
            s4532807_os_CAG_Simulator_clear_board(); // clear board
            s4532807_os_CAG_Simulator_write_to_display(); // write to disp.
        }
        
        /* Simulate only after the update interval has passed (updateRate) */
        if (simulatorState == STATE_RUNNING) {
            if ((currentTick - lastTick) >= updateRate) { // updateRate elapsed
                s4532807_os_CAG_Simulator_simulate(); // simulate
                s4532807_os_CAG_Simulator_write_to_display(); // write to disp.
                s4532807_os_CAG_Simulator_write_lta1000g(); // toggle LED 9
                lastTick = xTaskGetTickCount(); // update tick
            }
        }

        // get update rate from function which checks corresponding bits
        updateRate = s4532807_os_CAG_Simulator_get_update_time();
        
        // get state (stop/start) from function which checks corresponding bits
        simulatorState = s4532807_os_CAG_Simulator_get_simulator_state();        

        currentTick = xTaskGetTickCount(); // update time for simulation delay

		// Run every 50 ms
		vTaskDelay(50);
	}    
}

/*
 * This function simply writes the board to the display queue, if the display
 * queue exists. Note: the function is only and should only be called when an
 * update to the board has occured (new simulation, addition/removal of 
 * cell/lifeform or board cleared). This is to prevent unnecessary printing of
 * the board (which can make the display to lag behind the simulations). 
 */
void s4532807_os_CAG_Simulator_write_to_display(void) {
    if ((s4532807_QueueCAG_Display != NULL)) {
 
        if(xQueueSendToBack(s4532807_QueueCAG_Display, (void *) &nextBoard, 
                           (portTickType) 10 ) != pdPASS) {

    	    portENTER_CRITICAL();
		    debug_printf("Failed to post after 10 ticks. sim->display\n\r");
		    portEXIT_CRITICAL();
	    }
    }
}

/*
 * This function waits on the clear bit of the simulator event group. If the 
 * bit has been set then 1 is returned (which makes the simulator task clear
 * the board). Otherwise 0 is returned and the simulator task does not clear
 * the board. If the bit was set, it is cleared.
 */
int s4532807_os_CAG_Simulator_get_clear_bit(void) {
    int clearBit = 0;
    EventBits_t simulatorBits;

    simulatorBits = xEventGroupWaitBits(s4532807_EventCAG_Simulator, 
                                        CLEAR_GRID, pdTRUE, pdFALSE, 10);

    // clear bit has been set
    if ((simulatorBits & CLEAR_GRID) != 0) {
        clearBit = 1; // set flag

        // clear the bit
        simulatorBits = xEventGroupClearBits(s4532807_EventCAG_Simulator, 
                                                                    CLEAR_GRID);        
    }

    return clearBit;
}

/*
 * This function returns the state of the simulator based on the start and stop
 * event bits of the simulator event group. If the start bit is set then 
 * STATE_RUNNING is returned. If the stop bit is set, then STATE_STOPPED is 
 * returned, which prevents further simulations in the simulator task until the 
 * start bit is set again.
 */
int s4532807_os_CAG_Simulator_get_simulator_state(void) {

    EventBits_t simulatorBits;
    int simulatorState = STATE_RUNNING;

    simulatorBits = xEventGroupWaitBits(s4532807_EventCAG_Simulator, 
                                   START_STOP_CTRL, pdFALSE, pdFALSE, 10);

    if ((simulatorBits & START_SIM) != 0) {
        simulatorState = STATE_RUNNING;
    } else if ((simulatorBits & STOP_SIM) != 0) {
        simulatorState = STATE_STOPPED;
    }

    return simulatorState;
}

/*
 * This function returns the updateRate of the simulator based on the simulator
 * event group bits. The simulator task then waits for the duration of 
 * updateRate before each simulation.
 */
int s4532807_os_CAG_Simulator_get_update_time(void) {

    EventBits_t simulatorBits;
    int updateRate = 2000; 

    // wait on simulator update time event bits
    simulatorBits = xEventGroupWaitBits(s4532807_EventCAG_Simulator, 
                                        UPD_CTRL, pdFALSE, pdFALSE, 10);
    
    // iterate through update rate bits and check if they have been set
    for (int i = 3; i <= 7; i++) {
        if ((simulatorBits & (1 << i)) != 0) { // if bit was set
            
            // clear the bit
            simulatorBits = xEventGroupClearBits(s4532807_EventCAG_Simulator, 
                                                                      (1 << i));

            if (i == 3) {
                // corresponds to UPD_HALFSEC bit
                updateRate = 500;
            } else if (i == 4) {
                // corresponds to UPD_ONESEC bit
                updateRate = 1000;
            } else if (i == 5) {
                // corresponds to UPD_TWOSEC bit
                updateRate = 2000;
            } else if (i == 6) {
                // corresponds to UPD_FIVESEC bit
                updateRate = 5000;
            } else if (i == 7) {
                // corresponds to UPD_TENSEC bit
                updateRate = 10000;
            }

            return updateRate;
        }
    }
    		
    return updateRate;
}

/*
 * This function parses a given caMessage_t message. Checks the upper and lower
 * 4 bits of the type to determine what kind of cell/lifeform to draw. Then it 
 * uses the cell_x and cell_y position to draw onto the board. Calling function
 * should ensure the board is then written to the display queue.
 */
void s4532807_os_CAG_Simulator_draw_from_message(caMessage_t message) {
    uint8_t upper = (message.type & 0b11110000); // keep upper 4 bits
    upper = upper >> 4; // bit shift to get correct value
    uint8_t lower = (message.type & 0b00001111); // keep lower 4 bits

    int x = message.cell_x;
    int y = message.cell_y;

    if (upper == 1) { // cell
        // check dead/alive
        if (lower == 0) {
            // draw dead cell
            s4532807_os_CAG_Simulator_kill_cell(x, y);
        } else if (lower == 1) {
            // draw alive cell
            s4532807_os_CAG_Simulator_draw_cell(x, y);     
        }
    } else if (upper == 2) { // still life
        // check lower bits for type
        if (lower == 0) {
            // draw block
            s4532807_os_CAG_Simulator_draw_block(x, y);
        } else if (lower == 1) {
            // draw beehive
            s4532807_os_CAG_Simulator_draw_beehive(x, y);
        } else if (lower == 2) {
            // draw loaf
            s4532807_os_CAG_Simulator_draw_loaf(x, y);
        } 
    } else if (upper == 3) { // oscillator
        // check lower bits for type
        if (lower == 0) {
            // draw blinker
            s4532807_os_CAG_Simulator_draw_blinker(x, y);
        } else if (lower == 1) {
            // draw toad            
            s4532807_os_CAG_Simulator_draw_toad(x, y);
        } else if (lower == 2) {
            // draw beacon
            s4532807_os_CAG_Simulator_draw_beacon(x, y);
        }
    } else if (upper == 4) { // space ship
        // check lower bits for type
        if (lower == 0) {
            // draw glider
            s4532807_os_CAG_Simulator_draw_glider(x, y);
        }
    }    
}

/*
 * This function iterates through the board and sets each cell to 0 (dead).
 */
void s4532807_os_CAG_Simulator_clear_board(void) {
    for (int i = 0; i < 15; i++) {
        for (int j = 0; j < 15; j++) {
            // zero every cell
            nextBoard[i][j] = 0;        
        }
    }
}

/*
 * This function toggles the lta1000g LED 9. It preserves the value of all 
 * other bits. The function should be called upon every simulation to toggle
 * LED9. 
 */
void s4532807_os_CAG_Simulator_write_lta1000g(void) {
    // retrieve current value of LED bar
    uint16_t ledBitsSend = currentLEDBits;

    uint16_t simulatorBit = ledBitsSend & 0b0000001000000000;
    
    if (simulatorBit != 0) { // previously LED 9 on
        ledBitsSend = ledBitsSend & 0b0000000111111111; // turn LED 9 off
    } else { // previously LED 9 off
        ledBitsSend = ledBitsSend | (1 << 9); // turn LED 9 on
    }
    
    // write to queue
    if (s4532807_QueueLta1000gWrite != NULL) {
        if(xQueueSendToFront(s4532807_QueueLta1000gWrite, (void *) &ledBitsSend, 
                             (portTickType) 10 ) != pdPASS) {
			portENTER_CRITICAL();
	        debug_printf("Failed to post after 10 ticks.\n\r");
            portEXIT_CRITICAL();
        }
    }    
}

/*
 * This function iterates through every cell on the board and calculates the
 * number of neighbours the cell has. Then based on the CGoL rules, decides 
 * whether the cell will live/die or be born in the next generation. This 
 * function has been adapted from the website linked below:
 * https://processing.org/examples/gameoflife.html
 * 
 * Calling function should write board to display following this function.
 */
void s4532807_os_CAG_Simulator_simulate(void) {
    // create a copy of the board
    for (int i = 0; i < 15; i++) {
        for (int j = 0; j < 15; j++) {
            currentBoard[i][j] = nextBoard[i][j];
        }
    }

    // iterate through each cell and calculate neighbours
    for (int i = 0; i < 15; i++) {

        for (int j = 0; j < 15; j++) {
            int numNeighbours = 0;
            
            for (int a = (i-1); a <= (i+1); a++) {
                for (int b = (j-1); b <= (j+1); b++) {
                    if (((a>=0)&&(a<15))&&((b>=0)&&(b<15))) {
                        if (!((a==i)&&(b==j))) {
                            if (currentBoard[a][b] == 1) {
                                numNeighbours++;
                            }
                        }
                    }
                }
            }
            // checked neighbours, now apply rules
            if (currentBoard[i][j] == 1) { // currently alive
                if (numNeighbours < 2 || numNeighbours > 3) {
                    nextBoard[i][j] = 0; // die unless 2 or 3 neighbours
                }
            } else { // currently dead
                if (numNeighbours == 3) { // exactly 3 neighbours
                    nextBoard[i][j] = 1; // be born from reproduction                    
                }
            }            
        }
    } 
}

/*
 * This function sets the state of the cell at given x, y position to alive (1).
 * It ensures that the given x and y are within the board.
 */
void s4532807_os_CAG_Simulator_draw_cell(int x, int y) {
    // ensure x & y are inside the board
    if ((x < 15) && (x >= 0) && (y < 15) && (y >= 0)) { 
        nextBoard[x][y] = 1;
    }
}

/*
 * This function sets the state of the cell at given x, y position to dead (0).
 * It ensures that the given x and y are within the board.
 */
void s4532807_os_CAG_Simulator_kill_cell(int x, int y) {
    // ensure x and y are inside the board
    if ((x < 15) && (x >= 0) && (y < 15) && (y >= 0)) { 
        nextBoard[x][y] = 0;
    }
}

/*
 * This function draws a CGoL block at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_block(int x, int y) {
    // 11
    // 11

    s4532807_os_CAG_Simulator_draw_cell(x, y);
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y);
    s4532807_os_CAG_Simulator_draw_cell(x, y + 1);
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y + 1);
}

/*
 * This function draws a CGoL beehive at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_beehive(int x, int y) {
    // 0110
    // 1001
    // 0110

    /* X, Y are treated as topmost alive cell */

    s4532807_os_CAG_Simulator_kill_cell(x - 1, y); // 0
    s4532807_os_CAG_Simulator_draw_cell(x, y);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y); // 0

    s4532807_os_CAG_Simulator_draw_cell(x - 1, y + 1); // 1
    s4532807_os_CAG_Simulator_kill_cell(x, y + 1);     // 0
    s4532807_os_CAG_Simulator_kill_cell(x + 1, y + 1); // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y + 1); // 1

    s4532807_os_CAG_Simulator_kill_cell(x - 1, y + 2); // 0
    s4532807_os_CAG_Simulator_draw_cell(x, y + 2);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y + 2); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y + 2); // 0
}

/*
 * This function draws a CGoL loaf at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_loaf(int x, int y) {
    // 0110
    // 1001
    // 0101
    // 0010

    /* X, Y are treated as topmost alive cell */

    s4532807_os_CAG_Simulator_kill_cell(x - 1, y); // 0
    s4532807_os_CAG_Simulator_draw_cell(x, y);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y); // 0

    s4532807_os_CAG_Simulator_draw_cell(x - 1, y + 1); // 1
    s4532807_os_CAG_Simulator_kill_cell(x, y + 1);     // 0
    s4532807_os_CAG_Simulator_kill_cell(x + 1, y + 1); // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y + 1); // 1

    s4532807_os_CAG_Simulator_kill_cell(x - 1, y + 2); // 0
    s4532807_os_CAG_Simulator_draw_cell(x, y + 2);     // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 1, y + 2); // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y + 2); // 1
    
    s4532807_os_CAG_Simulator_kill_cell(x - 1, y + 3); // 0
    s4532807_os_CAG_Simulator_kill_cell(x, y + 3);     // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y + 3); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y + 3); // 0
}

/*
 * This function draws a CGoL blinker at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_blinker(int x, int y) {
    // 111

    /* X, Y are treated as topmost alive cell */

    s4532807_os_CAG_Simulator_draw_cell(x, y);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y); // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y); // 1
}

/*
 * This function draws a CGoL toad at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_toad(int x, int y) {
    // 0111
    // 1110

    /* X, Y are treated as topmost alive cell */

    s4532807_os_CAG_Simulator_kill_cell(x - 1, y); // 0
    s4532807_os_CAG_Simulator_draw_cell(x, y);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y); // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y); // 1

    s4532807_os_CAG_Simulator_draw_cell(x - 1, y + 1); // 1
    s4532807_os_CAG_Simulator_draw_cell(x, y + 1);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y + 1); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y + 1); // 0
}

/*
 * This function draws a CGoL beacon at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_beacon(int x, int y) {
    // 1100
    // 1100
    // 0011
    // 0011

    /* X, Y are treated as topmost alive cell */

    s4532807_os_CAG_Simulator_draw_cell(x, y);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y); // 0
    s4532807_os_CAG_Simulator_kill_cell(x + 3, y); // 0

    s4532807_os_CAG_Simulator_draw_cell(x, y + 1);     // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y + 1); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y + 1); // 0
    s4532807_os_CAG_Simulator_kill_cell(x + 3, y + 1); // 0

    s4532807_os_CAG_Simulator_kill_cell(x, y + 2);     // 0
    s4532807_os_CAG_Simulator_kill_cell(x + 1, y + 2); // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y + 2); // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 3, y + 2); // 1

    s4532807_os_CAG_Simulator_kill_cell(x, y + 3);     // 0
    s4532807_os_CAG_Simulator_kill_cell(x + 1, y + 3); // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y + 3); // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 3, y + 3); // 1
    
}

/*
 * This function draws a CGoL glider at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_glider(int x, int y) {
    // 101
    // 011
    // 010

    /* X, Y are treated as topmost alive cell */

    s4532807_os_CAG_Simulator_draw_cell(x, y);     // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 1, y); // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y); // 1

    s4532807_os_CAG_Simulator_kill_cell(x, y + 1);     // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y + 1); // 1
    s4532807_os_CAG_Simulator_draw_cell(x + 2, y + 1); // 1

    s4532807_os_CAG_Simulator_kill_cell(x, y + 2);     // 0
    s4532807_os_CAG_Simulator_draw_cell(x + 1, y + 2); // 1
    s4532807_os_CAG_Simulator_kill_cell(x + 2, y + 2); // 0  
    
}
