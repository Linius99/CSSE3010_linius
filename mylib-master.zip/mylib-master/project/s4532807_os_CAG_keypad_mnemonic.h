/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_keypad_mnemonic.h
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG keypad mnemonic driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_CAG_keypad_mnemonic_init(void) - init mnemonic mode
 * extern void s4532807_os_CAG_keypad_mnemonic_deinit(void) - deinit mnemonic
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAGKeypadMnemonic(void) - keypad mnemonic task, runs FSM 
 * void s4532807_os_CAG_keypad_mnemonic_clear_buffer(void) - clear keysPressed
 *      buffer
 * void s4532807_os_CAG_keypad_mnemonic_init_states(void) - initialise the state
 *      of the commands
 * int s4532807_os_CAG_keypad_mnemonic_check_for_command(void) - check buffer
 *      for every possible 13, 11 or 8 char commads
 * int s4532807_os_CAG_keypad_mnemonic_check_8_for_command(void) - check chars
 *      for an 8 char command
 * char s4532807_os_CAG_keypad_mnemonic_get_key(void) - gets pressed key
 * void s4532807_os_CAG_keypad_mnemonic_command_state(void) - FSM COMMAND_STATE 
 * void s4532807_os_CAG_keypad_mnemonic_type_state(void) - FSM TYPE_STATE
 * void s4532807_os_CAG_keypad_mnemonic_xval_state(void) - FSM XVAL_STATE
 * void s4532807_os_CAG_keypad_mnemonic_yval_state(void) - FSM YVAL_STATE
 * void s4532807_os_CAG_keypad_mnemonic_write_state(void) - FSM WRITE_STATE
 */

#ifndef s4532807_os_CAG_keypad_mnemonic_h_
#define s4532807_os_CAG_keypad_mnemonic_h_

/* Task Priorities -----------------------------------------------------------*/
#define TASKCAGKEYMNEMONIC_PRIORITY	            ( tskIDLE_PRIORITY + 2 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKCAGKEYMNEMONIC_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )


#include <string.h>
#include <stdbool.h>

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "event_groups.h"
#include "semphr.h"

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#include "s4532807_os_keypad.h" // to access Key press event bits
#include "s4532807_os_lta1000g.h" // to access current LED bar values
#include "s4532807_os_CAG_Simulator.h" // to draw cell and start/stop simulation
#include "s4532807_os_CAG_joystick.h" // to init and deinit

#define COMMAND_STATE 0
#define TYPE_STATE 1
#define XVAL_STATE 2
#define YVAL_STATE 3
#define WRITE_STATE 4

#define BUFFER_SIZE 13

char keysPressed[BUFFER_SIZE];

TaskHandle_t s4532807_TaskKeypadMnemonicHandle;

/*
 * This function creates the keypad mnemonic task and initialises the keys
 * pressed buffer.
 */
extern void s4532807_os_CAG_keypad_mnemonic_init(void);

/*
 * This function deletes the keypad mnemonic task.
 */
extern void s4532807_os_CAG_keypad_mnemonic_deinit(void);

/*
 * This is the keypad mnemonic task, if the mnemonic mode semaphore can be
 * obtained, then it processes the mnemonic FSM. The FSM has states COMMAND,
 * TYPE, XVAL YVAL and WRITE.
 */
void s4532807_TaskCAGKeypadMnemonic(void);

/*
 * This function sets all of the chars of the keysPressed buffer to an unused
 * character, so once a valid command is received, we can call this function 
 * to ensure the command will not be acted upon again.
 */
void s4532807_os_CAG_keypad_mnemonic_clear_buffer(void);

/*
 * This function sets the state of all commands to false.
 */
void s4532807_os_CAG_keypad_mnemonic_init_states(void);

/*
 * This function checks the currently stored 13 characters against all of the 
 * possible commands (13, 11, and 8 char long) to check if a valid command has 
 * been entered. If so, the state is updated accordingly, otherwise remain in
 * in command state. If any valid command is found, then the return value is 1,
 * otherwise the return value is 0.  
 */
int s4532807_os_CAG_keypad_mnemonic_check_for_command(void);

/*
 * If only 8 keys have been pressed, we don't use the sliding function, we can
 * simply compare the currently stored 8 characters to the 8 char commands
 * and see if it is a valid command. If a valid command was entered, the state
 * will be updated accordingly, otherwise we stay in command state. If valid 8
 * char command is found, 1 will be returned, else 0 is returned.
 */
int s4532807_os_CAG_keypad_mnemonic_check_8_for_command(void);

/*
 * This function waits on the key press event group bits. Gets which key was
 * pressed and stores it to a buffer of up to 13 characters. If 13 presses have 
 * occured, every next press removes the oldest character and the latest key is 
 * stored in the latest index. The pressed key is returned as a char, if no key
 * was pressed, the char 'Z' is returned instead.
 */
char s4532807_os_CAG_keypad_mnemonic_get_key(void);

/*
 * This is the command state function of the mnemonic FSM. If 0, D or F keys
 * are pressed then the simulator bit for clear, stop and start will be set 
 * respectively. If any other char is pressed and enough characters are present
 * in the buffer, then function to check the buffer for commands will be called.
 */
void s4532807_os_CAG_keypad_mnemonic_command_state(void);

/*
 * This function handles the TYPE_STATE of the mnemonicFSM. If the command was
 * DLT or CRE then the next key will lead to the corresponding driver being 
 * deleted (deinit) or created (init). If the command was STL, or OSC then the
 * next key determines what type of lifeform to draw, then the FSM proceeds to
 * the XVAL_STATE. If the command was GLD then we simply begin a 
 * mnemonicMessage of type spaceship and proceed to the XVAL_STATE. If no key is
 * pressed remain in TYPE_STATE or go back to COMMAND_STATE if invalid key is 
 * pressed.
 */
void s4532807_os_CAG_keypad_mnemonic_type_state(void);

/*
 * This function handles the XVAL_STATE of the mnemonic FSM. It reads which key
 * was pressed (if any), if the key is a valid subgrid key (0->4), then the 
 * appropriate cell_x value is set in the mnemonicMessage. Then the FSM proceeds 
 * to the YVAL_STATE. If no key was pressed then remains in XVAL_STATE. If an
 * invalid key is pressed, goes back to COMMAND_STATE.
 */
void s4532807_os_CAG_keypad_mnemonic_xval_state(void);

/*
 * This function handles the YVAL_STATE of the mnemonic FSM. It reads which key
 * was pressed (if any), if the key is a valid subgrid key (0->4), then the 
 * appropriate cell_y value is set in the mnemonicMessage. Then the FSM proceeds 
 * to the WRITE_STATE. If no key was pressed then remains in YVAL_STATE. If an
 * invalid key is pressed, goes back to COMMAND_STATE.
 */
void s4532807_os_CAG_keypad_mnemonic_yval_state(void);

/*
 * This function processes the WRITE_STATE of the mnemonic FSM. By the time
 * we reach this state, the mnemonicMessage struct has all the necessary fields
 * complete for the simulator queue, so this function writes to the the queue,
 * deletes the command chars from the buffer and sets the menmonic FSM state to
 * command state to continue receiving commands.
 */
void s4532807_os_CAG_keypad_mnemonic_write_state(void);

#endif
