/** 
 **************************************************************
 * @file mylib/project/s4532807_os_CAG_Simulator.h
 * @author Linius Zaman 45328077
 * @date 13/05/2020
 * @brief mylib CAG Simulator driver
 *        Ref: https://processing.org/examples/gameoflife.html CGoL simulation
 *             algorithm was derived from this website, used in function
 *             s4532807_os_CAG_Simulator_simulate();
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_os_CAG_Simulator_init(void) - CAG Simulator init
 * void s4532807_os_CAG_Simulator_deinit(void) - CAG Simulator deinit
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskCAG_Simulator(void) - CAG Simulator task
 * void s4532807_os_CAG_Simulator_write_to_display(void) - writes to disp. queue
 * int s4532807_os_CAG_Simulator_get_clear_bit(void) - waits on clear event bit
 * int s4532807_os_CAG_Simulator_get_simulator_state(void) - waits on start/stop
 * int s4532807_os_CAG_Simulator_get_update_time(void) - waits on update bits
 * void s4532807_os_CAG_Simulator_draw_from_message(caMessage_t message) - 
 * parses a caMessage and calls necessary functions to draw it
 * void s4532807_os_CAG_Simulator_clear_board(void) - clears board
 * void s4532807_os_CAG_Simulator_draw_cell(int x, int y) - draws an alive cell
 * void s4532807_os_CAG_Simulator_kill_cell(int x, int y) - kills cell
 * void s4532807_os_CAG_Simulator_draw_block(int x, int y) - draws block
 * void s4532807_os_CAG_Simulator_draw_beehive(int x, int y) - draws beehive
 * void s4532807_os_CAG_Simulator_draw_loaf(int x, int y) - draws loaf
 * void s4532807_os_CAG_Simulator_draw_blinker(int x, int y) - draws blinker
 * void s4532807_os_CAG_Simulator_draw_beacon(int x, int y) - draws beacon
 * void s4532807_os_CAG_Simulator_draw_glider(int x, int y) - draws glider
 * void s4532807_os_CAG_Simulator_draw_toad(int x, int y) - draws toad
 ***************************************************************
 */

#ifndef s4532807_os_CAG_Simulator_h_
#define s4532807_os_CAG_Simulator_h_

/* Includes ------------------------------------------------------------------*/
#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "event_groups.h"

/* Task Priorities -----------------------------------------------------------*/
#define TASKCAGSIMULATOR_PRIORITY	            ( tskIDLE_PRIORITY + 3 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKCAGSIMULATOR_TASK_STACK_SIZE	   ( configMINIMAL_STACK_SIZE * 5 )

/* Private define ------------------------------------------------------------*/
#define STATE_RUNNING 1
#define STATE_STOPPED 0

#define CLEAR_GRID    1 << 0
#define START_SIM     1 << 1
#define STOP_SIM      1 << 2
#define UPD_HALFSEC   1 << 3
#define UPD_ONESEC    1 << 4
#define UPD_TWOSEC    1 << 5
#define UPD_FIVESEC   1 << 6
#define UPD_TENSEC    1 << 7

#define UPD_CTRL 0b11111000

#define START_STOP_CTRL START_SIM | STOP_SIM

#include "s4532807_os_CAG_Display.h"
#include "s4532807_os_lta1000g.h" // access lta1000g value and queue to write

// handle for task, queue, event group required to init and deinit correctly
TaskHandle_t s4532807_TaskCAG_SimulatorHandle;
QueueHandle_t s4532807_QueueCAG_Simulator;
EventGroupHandle_t s4532807_EventCAG_Simulator;

// struct to store simulator message
typedef struct caMessage {
    int type; // Type - Cell , or Lifeform
    int cell_x; // Cell x position or Lifeform x position
    int cell_y; // Cell y position or Lifeform y position
} caMessage_t;

int currentBoard[15][15]; // store current board
int nextBoard[15][15]; // store next board

/*
 * Simulator os init function; creates task, queue and event group for the 
 * CAG Simulator.
 */
extern void s4532807_os_CAG_Simulator_init(void);

/*
 * Simulator deinit function; deletes task, queue and event group for the 
 * CAG Simulator.
 */
extern void s4532807_os_CAG_Simulator_deinit(void);

/*
 * This is the CAG Simulator task, it checks the simulator queue for cells or
 * lifeforms to draw. If something is to be drawn, it calls the necessary 
 * function to parse the message and draw on the board. It then writes the 
 * board to the display queue. If the duration of the updateRate has elapsed, 
 * then it calls the CGoL simulation on the board, then writes the board to the 
 * display queue. Functions which check the simulator updateRate, start, stop 
 * and clear bits are also called and the task performs as necessary.
 */
void s4532807_TaskCAG_Simulator(void);

/*
 * This function simply writes the board to the display queue, if the display
 * queue exists. Note: the function is only and should only be called when an
 * update to the board has occured (new simulation, addition/removal of 
 * cell/lifeform or board cleared). This is to prevent unnecessary printing of
 * the board (which can make the display to lag behind the simulations). 
 */
void s4532807_os_CAG_Simulator_write_to_display(void);

/*
 * This function toggles the lta1000g LED 9. It preserves the value of all 
 * other bits. The function should be called upon every simulation to toggle
 * LED9. 
 */
void s4532807_os_CAG_Simulator_write_lta1000g(void);

/*
 * This function iterates through every cell on the board and calculates the
 * number of neighbours the cell has. Then based on the CGoL rules, decides 
 * whether the cell will live/die or be born in the next generation. This 
 * function has been adapted from the website linked below:
 * https://processing.org/examples/gameoflife.html
 * 
 * Calling function should write board to display following this function.
 */
void s4532807_os_CAG_Simulator_simulate(void);

/*
 * This function parses a given caMessage_t message. Checks the upper and lower
 * 4 bits of the type to determine what kind of cell/lifeform to draw. Then it 
 * uses the cell_x and cell_y position to draw onto the board. Calling function
 * should ensure the board is then written to the display queue.
 */
void s4532807_os_CAG_Simulator_draw_from_message(caMessage_t message);

/*
 * This function waits on the clear bit of the simulator event group. If the 
 * bit has been set then 1 is returned (which makes the simulator task clear
 * the board). Otherwise 0 is returned and the simulator task does not clear
 * the board. If the bit was set, it is cleared.
 */
int s4532807_os_CAG_Simulator_get_clear_bit(void);

/*
 * This function returns the state of the simulator based on the start and stop
 * event bits of the simulator event group. If the start bit is set then 
 * STATE_RUNNING is returned. If the stop bit is set, then STATE_STOPPED is 
 * returned, which prevents further simulations in the simulator task until the 
 * start bit is set again.
 */
int s4532807_os_CAG_Simulator_get_simulator_state(void);

/*
 * This function returns the updateRate of the simulator based on the simulator
 * event group bits. The simulator task then waits for the duration of 
 * updateRate before each simulation.
 */
int s4532807_os_CAG_Simulator_get_update_time(void);

/*
 * This function iterates through the board and sets each cell to 0 (dead).
 */
void s4532807_os_CAG_Simulator_clear_board(void);

/*
 * This function sets the state of the cell at given x, y position to alive (1).
 * It ensures that the given x and y are within the board.
 */
void s4532807_os_CAG_Simulator_draw_cell(int x, int y);

/*
 * This function sets the state of the cell at given x, y position to dead (0).
 * It ensures that the given x and y are within the board.
 */
void s4532807_os_CAG_Simulator_kill_cell(int x, int y);

/*
 * This function draws a CGoL block at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_block(int x, int y);

/*
 * This function draws a CGoL beehive at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_beehive(int x, int y);

/*
 * This function draws a CGoL loaf at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_loaf(int x, int y);

/*
 * This function draws a CGoL blinker at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_blinker(int x, int y);

/*
 * This function draws a CGoL toad at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_toad(int x, int y);

/*
 * This function draws a CGoL beacon at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_beacon(int x, int y);

/*
 * This function draws a CGoL glider at the given x and y. Each cell of the 
 * lifeform is checked to see if it is within x and y boundaries of the board.
 * If any cell is out of bounds, it is simply ignored. 
 */
void s4532807_os_CAG_Simulator_draw_glider(int x, int y);

#endif
