/** 
 **************************************************************
 * @file mylib/s4532807_hal_lta1000g.c
 * @author Linius Zaman 45328077
 * @date 30/03/2020
 * @brief mylib lta1000g driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_lta1000g_init(void) - init function for lta1000g
 * extern void s4532807_os_lta1000g_deinit(void) - deinit function
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskLta1000g(void) - Lta1000g task, reads from queue, writes 
 * to lta1000g
 * void s4532807_os_lta1000g_write(unsigned short value) - wrapper function for 
 * the hal lta1000g write function
 */

#include "s4532807_os_lta1000g.h"

uint16_t ledBitsReceived = 0b0000000000000000; // store LED value to write

/*
 * Initialises necessary task, queue and hal GPIO
 */
extern void s4532807_os_lta1000g_init(void) {
    // create task
    xTaskCreate((void *) &s4532807_TaskLta1000g, (const signed char *) "WRITE", 
            TASKLTA1000GWRITE_TASK_STACK_SIZE, NULL, TASKLTA1000GWRITE_PRIORITY,
                                                  &s4532807_TaskLta1000gHandle);
    // create queue
    s4532807_QueueLta1000gWrite = xQueueCreate(10, sizeof(ledBitsReceived));

    // initialise the GPIO using hal function
    s4532807_hal_lta1000g_init();
}

/*
 * Denitialises (deletes) the lta1000g task and queue
 */
extern void s4532807_os_lta1000g_deinit(void) {
    // delete task 
    vTaskDelete(s4532807_TaskLta1000gHandle);

    // delete queue
    vQueueDelete(s4532807_QueueLta1000gWrite);
}

/*
 * This is the Lta1000g task, it is responsible for reading LED values from the
 * Lta1000g write queue and writing these value to the led bar. 
 * The queue MUST be used to send LED values (16 bit binary) to this task.
 */ 
void s4532807_TaskLta1000g(void) {  

    for (;;) {
        if (s4532807_QueueLta1000gWrite != NULL) {	/* Check if queue exists */

			/* Check for item received - block atmost for 10 ticks */
			if (xQueueReceive(s4532807_QueueLta1000gWrite, 
                              &ledBitsReceived, 10)) {
                
                // write received LED value
                s4532807_os_lta1000g_write(ledBitsReceived);

                // store current LED bits
                currentLEDBits = ledBitsReceived;
        	}
		}

		/* Delay for 10ms */
		vTaskDelay(10);
	}    

}

/*
 * Wrapper function to write value to led using hal write 
 */
void s4532807_os_lta1000g_write(unsigned short value) {
    s4532807_hal_lta1000g_write(value);
}



