/** 
 **************************************************************
 * @file mylib/s4532807_hal_lta1000g.h
 * @author Linius Zaman 45328077
 * @date 30/03/2020
 * @brief mylib lta1000g driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_lta1000g_init(void) - init function for lta1000g
 * extern void s4532807_os_lta1000g_deinit(void) - deinit function
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskLta1000g(void) - Lta1000g task, reads from queue, writes 
 * to lta1000g
 * void s4532807_os_lta1000g_write(unsigned short value) - wrapper function for 
 * the hal lta1000g write function
 */

#ifndef s4532807_os_lta1000g_h_
#define s4532807_os_lta1000g_h_

/* Task Priorities -----------------------------------------------------------*/
#define TASKLTA1000GWRITE_PRIORITY	            ( tskIDLE_PRIORITY + 2 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKLTA1000GWRITE_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"
#include "s4532807_hal_lta1000g.h"

// handle for task and queue, required to init and deinit correctly
TaskHandle_t s4532807_TaskLta1000gHandle;
QueueHandle_t s4532807_QueueLta1000gWrite; 

uint16_t currentLEDBits;

/*
 * Initialises necessary task, queue and hal GPIO
 */
extern void s4532807_os_lta1000g_init(void);

/*
 * Denitialises (deletes) the lta1000g task and queue
 */
extern void s4532807_os_lta1000g_deinit(void);

/*
 * This is the Lta1000g task, it is responsible for reading LED values from the
 * queue and writing the value to the led bar. The queue MUST be used to send
 * LED values (16 bit binary) to this task.
 */ 
void s4532807_TaskLta1000g(void);

/*
 * Wrapper function to write value to led using hal write 
 */
void s4532807_os_lta1000g_write(unsigned short value);

#endif
