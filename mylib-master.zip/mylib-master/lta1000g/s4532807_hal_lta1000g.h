/** 
 **************************************************************
 * @file mylib/s4532807_hal_lta1000g.h
 * @author Linius Zaman 45328077
 * @date 30/03/2020
 * @brief mylib lta1000g driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_lta1000g_init(void) - Initialise LED GPIO as outputs
 * extern void s4532807_hal_lta1000g_write(unsigned short value)
 * - write the LED segment to high or low using lta1000g_seg_set function
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void lta1000g_seg_set(int segment, unsigned char segment_value) 
 * - set the GPIO value to 0 or 1 on corresponding GPIO pin
 */

#ifndef s4532807_hal_lta1000g_h_
#define s4532807_hal_lta1000g_h_

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#ifdef S4532807_MYLIB_CONFIGURE_INC
#include "s4532807_hal_mylib_configure.h" 
#endif 

#ifndef S4532807_HAL_LTA1000G_PIN1
#define S4532807_HAL_LTA1000G_PIN1 BRD_D16_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT1
#define S4532807_HAL_LTA1000G_PORT1 BRD_D16_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK1
#define S4532807_HAL_LTA1000G_CLK1 __BRD_D16_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN2
#define S4532807_HAL_LTA1000G_PIN2 BRD_D17_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT2
#define S4532807_HAL_LTA1000G_PORT2 BRD_D17_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK2
#define S4532807_HAL_LTA1000G_CLK2 __BRD_D17_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN3
#define S4532807_HAL_LTA1000G_PIN3 BRD_D18_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT3
#define S4532807_HAL_LTA1000G_PORT3 BRD_D18_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK3
#define S4532807_HAL_LTA1000G_CLK3 __BRD_D18_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN4
#define S4532807_HAL_LTA1000G_PIN4 BRD_D19_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT4
#define S4532807_HAL_LTA1000G_PORT4 BRD_D19_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK4
#define S4532807_HAL_LTA1000G_CLK4 __BRD_D19_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN5
#define S4532807_HAL_LTA1000G_PIN5 BRD_D20_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT5
#define S4532807_HAL_LTA1000G_PORT5 BRD_D20_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK5
#define S4532807_HAL_LTA1000G_CLK5 __BRD_D20_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN6
#define S4532807_HAL_LTA1000G_PIN6 BRD_D21_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT6
#define S4532807_HAL_LTA1000G_PORT6 BRD_D21_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK6
#define S4532807_HAL_LTA1000G_CLK6 __BRD_D21_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN7
#define S4532807_HAL_LTA1000G_PIN7 BRD_D22_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT7
#define S4532807_HAL_LTA1000G_PORT7 BRD_D22_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK7
#define S4532807_HAL_LTA1000G_CLK7 __BRD_D22_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN8
#define S4532807_HAL_LTA1000G_PIN8 BRD_D23_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT8
#define S4532807_HAL_LTA1000G_PORT8 BRD_D23_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK8
#define S4532807_HAL_LTA1000G_CLK8 __BRD_D23_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN9
#define S4532807_HAL_LTA1000G_PIN9 BRD_D24_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT9
#define S4532807_HAL_LTA1000G_PORT9 BRD_D24_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK9
#define S4532807_HAL_LTA1000G_CLK9 __BRD_D24_GPIO_CLK()
#endif

#ifndef S4532807_HAL_LTA1000G_PIN10
#define S4532807_HAL_LTA1000G_PIN10 BRD_D25_PIN
#endif

#ifndef S4532807_HAL_LTA1000G_PORT10
#define S4532807_HAL_LTA1000G_PORT10 BRD_D25_GPIO_PORT
#endif

#ifndef S4532807_HAL_LTA1000G_CLK10
#define S4532807_HAL_LTA1000G_CLK10 __BRD_D25_GPIO_CLK()
#endif

/*
 * This function initialises all of the GPIO as necessary for the ledbar.
 */
extern void s4532807_hal_lta1000g_init(void);

/*
 * This function sets the high or low value for an individual LED.
 */
void lta1000g_seg_set(int segment, unsigned char segment_value);

/*
 * This function uses the 16bit binary value to set the appropriate high or low
 * value for each LED on the ledbar. It does so by calling the seg set function
 * iteratively. 
 */
extern void s4532807_hal_lta1000g_write(unsigned short value);


#endif
