/** 
 **************************************************************
 * @file mylib/s4532807_hal_lta1000g.c
 * @author Linius Zaman 45328077
 * @date 30/03/2020
 * @brief mylib lta1000g driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_lta1000g_init(void) - Initialise LED GPIO as outputs
 * extern void s4532807_hal_lta1000g_write(unsigned short value)
 * - write the LED segment to high or low using lta1000g_seg_set function
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void lta1000g_seg_set(int segment, unsigned char segment_value) 
 * - set the GPIO value to 0 or 1 on corresponding GPIO pin
 */

#include "s4532807_hal_lta1000g.h"

/*
 * This function initialises all of the GPIO as necessary for the ledbar.
 */
extern void s4532807_hal_lta1000g_init(void) {
    
    GPIO_InitTypeDef GPIO_InitStructure;
    
    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN1;
    GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStructure.Pull = GPIO_PULLDOWN;
    GPIO_InitStructure.Speed = GPIO_SPEED_FAST;
    S4532807_HAL_LTA1000G_CLK1;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT1, &GPIO_InitStructure);
    
    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN2;
    S4532807_HAL_LTA1000G_CLK2;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT2, &GPIO_InitStructure);
    
    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN3;
    S4532807_HAL_LTA1000G_CLK3;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT3, &GPIO_InitStructure);

    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN4;
    S4532807_HAL_LTA1000G_CLK4;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT4, &GPIO_InitStructure);

    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN5;
    S4532807_HAL_LTA1000G_CLK5;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT5, &GPIO_InitStructure);

    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN6;
    S4532807_HAL_LTA1000G_CLK6;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT6, &GPIO_InitStructure);

    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN7;
    S4532807_HAL_LTA1000G_CLK7;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT7, &GPIO_InitStructure);

    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN8;
    S4532807_HAL_LTA1000G_CLK8;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT8, &GPIO_InitStructure);
   
    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN9;
    S4532807_HAL_LTA1000G_CLK9; 
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT9, &GPIO_InitStructure);
    
    GPIO_InitStructure.Pin = S4532807_HAL_LTA1000G_PIN10;
    S4532807_HAL_LTA1000G_CLK10;
    HAL_GPIO_Init(S4532807_HAL_LTA1000G_PORT10, &GPIO_InitStructure);

}

/*
 * This function sets the high or low value for an individual LED.
 */
void lta1000g_seg_set(int segment, unsigned char segment_value) {
    int value;    

    if (segment_value > 0) {
        value = 1;            
    } else {
        value = 0;
    }

    if (segment == 0) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT1, 
                            S4532807_HAL_LTA1000G_PIN1, value);
    } else if (segment == 1) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT2, 
                            S4532807_HAL_LTA1000G_PIN2, value);
    } else if (segment == 2) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT3, 
                            S4532807_HAL_LTA1000G_PIN3, value);
    } else if (segment == 3) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT4, 
                            S4532807_HAL_LTA1000G_PIN4, value);
    } else if (segment == 4) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT5, 
                            S4532807_HAL_LTA1000G_PIN5, value);
    } else if (segment == 5) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT6, 
                            S4532807_HAL_LTA1000G_PIN6, value);
    } else if (segment == 6) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT7, 
                            S4532807_HAL_LTA1000G_PIN7, value);
    } else if (segment == 7) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT8, 
                            S4532807_HAL_LTA1000G_PIN8, value);
    } else if (segment == 8) {
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT9, 
                            S4532807_HAL_LTA1000G_PIN9, value);
    } else if (segment == 9) {      
        HAL_GPIO_WritePin(S4532807_HAL_LTA1000G_PORT10, 
                            S4532807_HAL_LTA1000G_PIN10, value);
    }
}

/*
 * This function uses the 16bit binary value to set the appropriate high or low
 * value for each LED on the ledbar. It does so by calling the seg set function
 * iteratively. 
 */
extern void s4532807_hal_lta1000g_write(unsigned short value) {
    for (int i = 0; i < 10; i++) {
        lta1000g_seg_set(i, !!(value & (1 << i)));    
    }
}
