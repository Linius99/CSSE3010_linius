/** 
 **************************************************************
 * @file mylib/s4532807_hal_keypad.h
 * @author Linius Zaman 45328077
 * @date 10/04/2020
 * @brief mylib keypad driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_keypad_init() - Set keypadFSM to INIT state
 * extern void s4532807_hal_keypad_fsmprocessing() - Keypad FSM processing loop
 * extern void keypad_gpio_init() - Initalise all GPIO pins.
 * extern int s4532807_hal_keypad_read_status() - Return KeypadStatus variable.
 * extern unsigned char s4532807_hal_keypad_read_ascii() - Return the current 
 *                                                    ASCII value of the keypad
 * extern uint8_t s4532807_hal_keypad_read_key() - Return the current 
 *                                              hexadecimal value of the keypad.
 * extern void s4532807_hal_keypad_deinit() - Set keypadFSM to DEINIT state 
 ***************************************************************
 * INTERNAL FUNCTIONS
 ***************************************************************
 * void keypad_writecol(uint8_t colval) - Function to activate a column.
 * uint8_t keypad_readrow() - Function for reading a row   
 *************************************************************** 
 */

#ifndef s4532807_hal_keypad_h_
#define s4532807_hal_keypad_h_

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#ifdef S4532807_MYLIB_CONFIGURE_INC
#include "s4532807_hal_mylib_configure.h"
#endif

#ifndef S4532807_HAL_KEYPAD_COL1PIN
#define S4532807_HAL_KEYPAD_COL1PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_COL2PIN
#define S4532807_HAL_KEYPAD_COL2PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_COL3PIN
#define S4532807_HAL_KEYPAD_COL3PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_COL4PIN
#define S4532807_HAL_KEYPAD_COL4PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_COL1PINPORT
#define S4532807_HAL_KEYPAD_COL1PINPORT BRD_D0_GPIO_PORT
#endif 

#ifndef S4532807_HAL_KEYPAD_COL2PINPORT
#define S4532807_HAL_KEYPAD_COL2PINPORT BRD_D0_GPIO_PORT
#endif 

#ifndef S4532807_HAL_KEYPAD_COL3PINPORT
#define S4532807_HAL_KEYPAD_COL3PINPORT BRD_D0_GPIO_PORT
#endif 

#ifndef S4532807_HAL_KEYPAD_COL4PINPORT
#define S4532807_HAL_KEYPAD_COL4PINPORT BRD_D0_GPIO_PORT
#endif 

#ifndef S4532807_HAL_KEYPAD_COL1PINCLK
#define S4532807_HAL_KEYPAD_COL1PINCLK __BRD_D0_GPIO_CLK()
#endif 

#ifndef S4532807_HAL_KEYPAD_COL2PINCLK
#define S4532807_HAL_KEYPAD_COL2PINCLK __BRD_D0_GPIO_CLK()
#endif

#ifndef S4532807_HAL_KEYPAD_COL3PINCLK
#define S4532807_HAL_KEYPAD_COL3PINCLK __BRD_D0_GPIO_CLK()
#endif

#ifndef S4532807_HAL_KEYPAD_COL4PINCLK
#define S4532807_HAL_KEYPAD_COL4PINCLK __BRD_D0_GPIO_CLK()
#endif

#ifndef S4532807_HAL_KEYPAD_ROW1PIN
#define S4532807_HAL_KEYPAD_ROW1PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW2PIN
#define S4532807_HAL_KEYPAD_ROW2PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW3PIN
#define S4532807_HAL_KEYPAD_ROW3PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW4PIN
#define S4532807_HAL_KEYPAD_ROW4PIN BRD_D0_PIN
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW1PINPORT
#define S4532807_HAL_KEYPAD_ROW1PINPORT BRD_D0_GPIO_PORT
#endif

#ifndef S4532807_HAL_KEYPAD_ROW2PINPORT
#define S4532807_HAL_KEYPAD_ROW2PINPORT BRD_D0_GPIO_PORT
#endif

#ifndef S4532807_HAL_KEYPAD_ROW3PINPORT
#define S4532807_HAL_KEYPAD_ROW3PINPORT BRD_D0_GPIO_PORT
#endif

#ifndef S4532807_HAL_KEYPAD_ROW4PINPORT
#define S4532807_HAL_KEYPAD_ROW4PINPORT BRD_D0_GPIO_PORT
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW1PINCLK
#define S4532807_HAL_KEYPAD_ROW1PINCLK __BRD_D0_GPIO_CLK()
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW2PINCLK
#define S4532807_HAL_KEYPAD_ROW2PINCLK __BRD_D0_GPIO_CLK()
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW3PINCLK
#define S4532807_HAL_KEYPAD_ROW3PINCLK __BRD_D0_GPIO_CLK()
#endif 

#ifndef S4532807_HAL_KEYPAD_ROW4PINCLK
#define S4532807_HAL_KEYPAD_ROW4PINCLK __BRD_D0_GPIO_CLK()
#endif 

#define INIT_STATE 0
#define COL1_STATE 1
#define COL2_STATE 2
#define COL3_STATE 3
#define COL4_STATE 4
#define ROWSCAN_STATE 5
#define DEINIT_STATE 6

#define keypad_col1() keypad_writecol(0b00000001)
#define keypad_col2() keypad_writecol(0b00000010)
#define keypad_col3() keypad_writecol(0b00000100)
#define keypad_col4() keypad_writecol(0b00001000)

static int KeypadFsmCurrentstate;
int KeypadStatus;
int currentCol;
unsigned char KeypadValue;


/* 
 * Set the state of the keypadFSM to INIT state.
 */
extern void s4532807_hal_keypad_init();

/*
 * Set the state of the keypadFSM to DEINIT state.
 */
extern void s4532807_hal_keypad_deinit();

/*
 * Keypad FSM processing function, called every 50ms from main to process reading
 * of the key pressed. Upon each call, the processing is done depending on the
 * current state. The col states set only the respective column low and the
 * other columns high. The row scan state reads the rows to find which row is 
 * currently low. The pressed key is determined based on the corresponding row
 * and column,  
 */
extern void s4532807_hal_keypad_fsmprocessing();

/*
 * This function initialises the GPIO for the keypad pins.
 */
void keypad_gpio_init();

/*
 * This function writes low (0V) to the column which is given in the input.
 * 0x01 sets column 1 low, 0x02 sets column 2 low, 0x04 sets column 3 low and
 * 0x08 sets column 4 low. All other columns are set high.
 */
void keypad_writecol(uint8_t colval);


/*
 * This function reads the logic level of each row pin. The return value is 
 * based on whichever row reads low.
 * 0x0E returned if row 1 is low, 0x0D if row 2 is low, 0x0B if row 3 is low
 * and 0x07 if row 4 is low. 
 */
uint8_t keypad_readrow();

/*
 * This function returns the current value of the KeypadStatus variable.
 */
extern int s4532807_hal_keypad_read_status();

/*
 * This function returns the current hex value of the key pressed (0x00 -> 0x0F)  
 */
extern uint8_t s4532807_hal_keypad_read_key();

/*
 * This function returns the current ascii value of the key pressed.
 */
extern unsigned char s4532807_hal_keypad_read_ascii();

#endif


