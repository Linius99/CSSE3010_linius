/** 
 **************************************************************
 * @file mylib/s4532807_hal_keypad.c
 * @author Linius Zaman 45328077
 * @date 10/04/2020
 * @brief mylib keypad driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_hal_keypad_init() - Set keypadFSM to INIT state
 * extern void s4532807_hal_keypad_fsmprocessing() - Keypad FSM processing loop
 * extern void keypad_gpio_init() - Initalise all GPIO pins.
 * extern int s4532807_hal_keypad_read_status() - Return KeypadStatus variable.
 * extern unsigned char s4532807_hal_keypad_read_ascii() - Return the current 
 *                                                    ASCII value of the keypad
 * extern uint8_t s4532807_hal_keypad_read_key() - Return the current 
 *                                              hexadecimal value of the keypad.
 * extern void s4532807_hal_keypad_deinit() - Set keypadFSM to DEINIT state 
 ***************************************************************
 * INTERNAL FUNCTIONS
 ***************************************************************
 * void keypad_writecol(uint8_t colval) - Function to activate a column.
 * uint8_t keypad_readrow() - Function for reading a row   
 *************************************************************** 
 */

#include "s4532807_hal_keypad.h"

/* 
 * Set the state of the keypadFSM to INIT state.
 */
extern void s4532807_hal_keypad_init() {
    KeypadFsmCurrentstate = INIT_STATE;
}

/*
 * Set the state of the keypadFSM to DEINIT state.
 */
extern void s4532807_hal_keypad_deinit() {
    KeypadFsmCurrentstate = DEINIT_STATE;
}

/*
 * Keypad FSM processing function, called every 50ms from main to process reading
 * of the key pressed. Upon each call, the processing is done depending on the
 * current state. The col states set only the respective column low and the
 * other columns high. The row scan state reads the rows to find which row is 
 * currently low. The pressed key is determined based on the corresponding row
 * and column,  
 */
extern void s4532807_hal_keypad_fsmprocessing() {
    uint8_t rowStatus;    
    KeypadStatus = 0;
    
    if (KeypadFsmCurrentstate == INIT_STATE) {
        // if initialised, begin with COL1_STATE       
        KeypadFsmCurrentstate = COL1_STATE;
    }      

    // if in a COLX_STATE, set respective column low using keypad_colX(). 
    // then set the FSM state to ROWSCAN_STATE
    if (KeypadFsmCurrentstate == COL1_STATE) {
        currentCol = 1;
        keypad_col1();
        KeypadFsmCurrentstate = ROWSCAN_STATE;
    } else if (KeypadFsmCurrentstate == COL2_STATE) {
        currentCol = 2;
        keypad_col2();    
        KeypadFsmCurrentstate = ROWSCAN_STATE;
    } else if (KeypadFsmCurrentstate == COL3_STATE) {
        currentCol = 3;
        keypad_col3();
        KeypadFsmCurrentstate = ROWSCAN_STATE;    
    } else if (KeypadFsmCurrentstate == COL4_STATE) {
        currentCol = 4;
        keypad_col4();
        KeypadFsmCurrentstate = ROWSCAN_STATE;

    // ROWSCAN_STATE processing     
    } else if (KeypadFsmCurrentstate == ROWSCAN_STATE) {
        // read logic level of rows        
        rowStatus = keypad_readrow();
        
        // if any row is low, key has been pressed
        if (rowStatus < 0b00001111) {
            KeypadStatus = 1;
        }
        
        // set KeypadValue based on key pressed (only happens if a col is low
        // and a row is also low)
        if (currentCol == 1) {
            KeypadFsmCurrentstate = COL2_STATE; // update FSM state
            if (rowStatus == 0b00001110) {
                KeypadValue = 0x01;
            } else if (rowStatus == 0b00001101) {
                KeypadValue = 0x04;
            } else if (rowStatus == 0b00001011) {
                KeypadValue = 0x07;
            } else if (rowStatus == 0b00000111) {
                KeypadValue = 0x00;                  
            }
        } else if (currentCol == 2) {
            KeypadFsmCurrentstate = COL3_STATE; // update FSM state
            if (rowStatus == 0b00001110) {
                KeypadValue = 0x02;
            } else if (rowStatus == 0b00001101) {
                KeypadValue = 0x05;
            } else if (rowStatus == 0b00001011) {
                KeypadValue = 0x08;
            } else if (rowStatus == 0b00000111) {
                KeypadValue = 0x0F;                  
            }
        } else if (currentCol == 3) {
            KeypadFsmCurrentstate = COL4_STATE; // update FSM state
            if (rowStatus == 0b00001110) {
                KeypadValue = 0x03;
            } else if (rowStatus == 0b00001101) {
                KeypadValue = 0x06;
            } else if (rowStatus == 0b00001011) {
                KeypadValue = 0x09;
            } else if (rowStatus == 0b00000111) {
                KeypadValue = 0x0E;                  
            }
        } else if (currentCol == 4) {
            KeypadFsmCurrentstate = COL1_STATE; // update FSM state
            if (rowStatus == 0b00001110) {
                KeypadValue = 0x0A;
            } else if (rowStatus == 0b00001101) {
                KeypadValue = 0x0B;
            } else if (rowStatus == 0b00001011) {
                KeypadValue = 0x0C;
            } else if (rowStatus == 0b00000111) {
                KeypadValue = 0x0D;                  
            }
        } 
    } else if (KeypadFsmCurrentstate == DEINIT_STATE) {
        // do nothing if in DEINIT_STATE
    }
}

/*
 * This function initialises the GPIO for the keypad pins.
 */
extern void keypad_gpio_init() {
    GPIO_InitTypeDef GPIO_InitStructure;
    
    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_COL1PIN;
    GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStructure.Pull = GPIO_NOPULL;
    GPIO_InitStructure.Speed = GPIO_SPEED_FAST;
    S4532807_HAL_KEYPAD_COL1PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_COL1PINPORT, &GPIO_InitStructure);
    
    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_COL2PIN;
    S4532807_HAL_KEYPAD_COL2PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_COL2PINPORT, &GPIO_InitStructure);
    
    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_COL3PIN;
    S4532807_HAL_KEYPAD_COL3PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_COL3PINPORT, &GPIO_InitStructure);
        
    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_COL4PIN;
    S4532807_HAL_KEYPAD_COL4PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_COL4PINPORT, &GPIO_InitStructure);

    // rows are input as we will read their value
    GPIO_InitStructure.Mode = GPIO_MODE_INPUT;
    GPIO_InitStructure.Pull = GPIO_NOPULL;
    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_ROW1PIN;
    S4532807_HAL_KEYPAD_ROW1PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_ROW1PINPORT, &GPIO_InitStructure);    

    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_ROW2PIN;
    S4532807_HAL_KEYPAD_ROW2PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_ROW2PINPORT, &GPIO_InitStructure);
    
    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_ROW3PIN;
    S4532807_HAL_KEYPAD_ROW3PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_ROW3PINPORT, &GPIO_InitStructure);
        
    GPIO_InitStructure.Pin = S4532807_HAL_KEYPAD_ROW4PIN;
    S4532807_HAL_KEYPAD_ROW4PINCLK;
    HAL_GPIO_Init(S4532807_HAL_KEYPAD_ROW4PINPORT, &GPIO_InitStructure);
}

/*
 * This function writes low (0V) to the column which is given in the input.
 * 0x01 sets column 1 low, 0x02 sets column 2 low, 0x04 sets column 3 low and
 * 0x08 sets column 4 low. All other columns are set high.
 */
void keypad_writecol(uint8_t colval) {
    HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL1PINPORT, 
                            S4532807_HAL_KEYPAD_COL1PIN, 1);
    HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL2PINPORT, 
                            S4532807_HAL_KEYPAD_COL2PIN, 1);
    HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL3PINPORT, 
                            S4532807_HAL_KEYPAD_COL3PIN, 1);
    HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL4PINPORT, 
                            S4532807_HAL_KEYPAD_COL4PIN, 1);

    if (colval == 0b00000001) {
        HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL1PINPORT, 
                            S4532807_HAL_KEYPAD_COL1PIN, 0);    
    } else if (colval == 0b00000010) {   
        HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL2PINPORT, 
                            S4532807_HAL_KEYPAD_COL2PIN, 0);
    } else if (colval == 0b00000100) {
        HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL3PINPORT, 
                            S4532807_HAL_KEYPAD_COL3PIN, 0);
    } else if (colval == 0b00001000) {
        HAL_GPIO_WritePin(S4532807_HAL_KEYPAD_COL4PINPORT, 
                            S4532807_HAL_KEYPAD_COL4PIN, 0);
    }
}


/*
 * This function reads the logic level of each row pin. The return value is 
 * based on whichever row reads low.
 * 0x0E returned if row 1 is low, 0x0D if row 2 is low, 0x0B if row 3 is low
 * and 0x07 if row 4 is low. 
 */
uint8_t keypad_readrow() {
    int row1, row2, row3, row4;

    row1 = HAL_GPIO_ReadPin(S4532807_HAL_KEYPAD_ROW1PINPORT, 
                                                S4532807_HAL_KEYPAD_ROW1PIN);
    row2 = HAL_GPIO_ReadPin(S4532807_HAL_KEYPAD_ROW2PINPORT, 
                                                S4532807_HAL_KEYPAD_ROW2PIN);
    row3 = HAL_GPIO_ReadPin(S4532807_HAL_KEYPAD_ROW3PINPORT, 
                                                S4532807_HAL_KEYPAD_ROW3PIN);
    row4 = HAL_GPIO_ReadPin(S4532807_HAL_KEYPAD_ROW4PINPORT, 
                                                S4532807_HAL_KEYPAD_ROW4PIN);
    
    // if row 1 is low, return 0b00001110 0x0E
    if (row1 == 0) {
        return 0b00001110;
    // if row 2 is low, return 0b00001101 0x0D
    } else if (row2 == 0) {
        return 0b00001101;
    // if row 3 is low, return 0b00001011 0x0B
    } else if (row3 == 0) {
        return 0b00001011;
    // if row 4 is low, return 0b00000111 0x07    
    } else if (row4 == 0) {
        return 0b00000111;
    // if none of the rows are low, return 0b00001111 0x0F
    } else {
        return 0b00001111;
    }
}

/*
 * This function returns the current value of the KeypadStatus variable.
 */
extern int s4532807_hal_keypad_read_status() {
    return KeypadStatus;
}

/*
 * This function returns the current hex value of the key pressed (0x00 -> 0x0F)  
 */
extern uint8_t s4532807_hal_keypad_read_key() {
    return KeypadValue; // return hex value of key pressed
}

/*
 * This function returns the current ascii value of the key pressed.
 */
extern unsigned char s4532807_hal_keypad_read_ascii() {
    unsigned char ascii = '0'; // initialise
    
    // ascii is the char which corresponds to the hex value
    if (KeypadValue == 0x01) {
        ascii = '1';
    } else if (KeypadValue == 0x02) {
        ascii = '2';
    } else if (KeypadValue == 0x03) {
        ascii = '3';
    } else if (KeypadValue == 0x04) {
        ascii = '4';
    } else if (KeypadValue == 0x05) {
        ascii = '5';
    } else if (KeypadValue == 0x06) {
        ascii = '6';
    } else if (KeypadValue == 0x07) {
        ascii = '7';
    } else if (KeypadValue == 0x08) {
        ascii = '8';
    } else if (KeypadValue == 0x09) {
        ascii = '9';
    } else if (KeypadValue == 0x0A) {
        ascii = 'A';
    } else if (KeypadValue == 0x0B) {
        ascii = 'B';
    } else if (KeypadValue == 0x0C) {
        ascii = 'C';
    } else if (KeypadValue == 0x0D) {
        ascii = 'D';
    } else if (KeypadValue == 0x0E) {
        ascii = 'E';
    } else if (KeypadValue == 0x0F) {
        ascii = 'F';
    }

    return ascii; // return the ascii value (char) of key pressed
}
