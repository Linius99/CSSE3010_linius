/** 
 **************************************************************
 * @file mylib/s4532807_os_keypad.h
 * @author Linius Zaman 45328077
 * @date 30/04/2020
 * @brief mylib os keypad driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_keypad_init(void) - os keypad init
 * extern void s4532807_os_keypad_deinit(void) - os keypad deinit
 * extern void PUSHBUTTON_IRQ_HANDLER(void) - pushbutton handler
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskKeypadRead(void) - os keypad read task
 * void EXTI15_10_IRQHandler(void) - IRQHandler
 */


#ifndef s4532807_os_keypad_h_
#define s4532807_os_keypad_h_

/* Task Priorities -----------------------------------------------------------*/
#define TASKKEYPAD_PRIORITY	            ( tskIDLE_PRIORITY + 2 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKKEYPAD_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "event_groups.h"
#include "semphr.h"

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#include "s4532807_hal_keypad.h"

/* Private define ------------------------------------------------------------*/
#define EVT_0   1 << 0
#define EVT_1   1 << 1
#define EVT_2   1 << 2
#define EVT_3   1 << 3
#define EVT_4   1 << 4
#define EVT_5   1 << 5
#define EVT_6   1 << 6
#define EVT_7   1 << 7
#define EVT_8   1 << 8
#define EVT_9   1 << 9
#define EVT_A   1 << 10
#define EVT_B   1 << 11
#define EVT_C   1 << 12
#define EVT_D   1 << 13
#define EVT_E   1 << 14
#define EVT_F   1 << 15

#define EVT_KEYPAD_CTRL 0xFFFF

// handle for task and event group, required to init and deinit correctly
TaskHandle_t s4532807_TaskKeypadHandle;
EventGroupHandle_t s4532807_EventKeypadKeyPress;

// semaphores for keypad modes
SemaphoreHandle_t s4532807_SemaphoreKeypadGrid;
SemaphoreHandle_t s4532807_SemaphoreKeypadMnemonic;

/*
 * Initialises necessary task and hal GPIO. Creates semaphores for grid and
 * mnemonic modes. Creates event group bits for key press event.  
 */
extern void s4532807_os_keypad_init(void);

/*
 * Deinit function for keypad, denitialises the hal keypad, deletes task
 * event group and semaphores.
 */
extern void s4532807_os_keypad_deinit(void);

/*
 * This is the keypad os task, it runs the keypadFSM function every 30ms and
 * checks if a key has been pressed, if so, it gets the key and sets the 
 * corresponding bit in the key press event group. All other bits are cleared.
 * Based on which mode the keypad is currently in, it gives the grid or mnemonic
 * semaphore so the keypress can be handled accordingly. Green LED is also
 * toggled per keypress. 
 */
void s4532807_TaskKeypadRead(void);

/*
 * IRQ handler for the push button, debounces the press (300ms).
 */
extern void PUSHBUTTON_IRQ_HANDLER(void);

#endif
