/** 
 **************************************************************
 * @file mylib/s4532807_os_keypad.c
 * @author Linius Zaman 45328077
 * @date 30/04/2020
 * @brief mylib os keypad driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern void s4532807_os_keypad_init(void) - os keypad init
 * extern void s4532807_os_keypad_deinit(void) - os keypad deinit
 * extern void PUSHBUTTON_IRQ_HANDLER(void) - pushbutton handler
 *************************************************************** 
 * INTERNAL FUNCTIONS 
 ***************************************************************
 * void s4532807_TaskKeypadRead(void) - os keypad read task
 * void EXTI15_10_IRQHandler(void) - IRQHandler
 */

#include "s4532807_os_keypad.h"

int pbLastTick = 0; // for debouncing pb
int keypadMode = 0; // 0 for grid, 1 for mnemonic

/*
 * Initialises necessary task and hal GPIO. Creates semaphores for grid and
 * mnemonic modes. Creates event group bits for key press event.  
 */
extern void s4532807_os_keypad_init(void) {
    // Initialise keypad GPIO in hal
    keypad_gpio_init();

    // Initialise push button GPIO 
    GPIO_InitTypeDef GPIO_InitStructure;

    BRD_USER_BUTTON_GPIO_CLK_ENABLE();

	GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;
	GPIO_InitStructure.Pull = GPIO_NOPULL;
	GPIO_InitStructure.Pin  = BRD_USER_BUTTON_PIN;
	HAL_GPIO_Init(BRD_USER_BUTTON_GPIO_PORT, &GPIO_InitStructure);

	HAL_NVIC_SetPriority(BRD_USER_BUTTON_EXTI_IRQn, 10, 0);
	HAL_NVIC_EnableIRQ(BRD_USER_BUTTON_EXTI_IRQn);

    // Initialise the keypad FSM state in hal INIT_STATE
    s4532807_hal_keypad_init();

    // create KEYPAD os task
    xTaskCreate((void *) &s4532807_TaskKeypadRead, 
              (const signed char *) "KEYREAD", TASKKEYPAD_TASK_STACK_SIZE, NULL, 
              TASKKEYPAD_PRIORITY, &s4532807_TaskKeypadHandle);
    
    // create event group bits to signal key press
    s4532807_EventKeypadKeyPress = xEventGroupCreate();

    // create push button semaphores for keypad mode
    s4532807_SemaphoreKeypadGrid = xSemaphoreCreateBinary();
    s4532807_SemaphoreKeypadMnemonic = xSemaphoreCreateBinary();
}

/*
 * Deinit function for keypad, denitialises the hal keypad, deletes task
 * event group and semaphores.
 */
extern void s4532807_os_keypad_deinit(void) {
    // de-initialise the keypad FSM state in hal DEINIT_STATE
    s4532807_hal_keypad_deinit();

    // delete keypad read task
    vTaskDelete(s4532807_TaskKeypadHandle);

    // delete key press event group
    vEventGroupDelete(s4532807_EventKeypadKeyPress);

    // delete grid and mnemonic semaphores
    vSemaphoreDelete(s4532807_SemaphoreKeypadGrid);
    vSemaphoreDelete(s4532807_SemaphoreKeypadMnemonic);
}

/*
 * This is the keypad os task, it runs the keypadFSM function every 30ms and
 * checks if a key has been pressed, if so, it gets the key and sets the 
 * corresponding bit in the key press event group. All other bits are cleared.
 * Based on which mode the keypad is currently in, it gives the grid or mnemonic
 * semaphore so the keypress can be handled accordingly. Green LED is also
 * toggled per keypress. 
 */
void s4532807_TaskKeypadRead(void) {  
    unsigned char keyPressed = 0x00; // initialise    
    EventBits_t keyBits;
    
    for (;;) {

        s4532807_hal_keypad_fsmprocessing(); // process keypad FSM
        
        if (s4532807_hal_keypad_read_status() == 1) {

            BRD_LEDGreenToggle(); // toggle Green LED on key press

            keyPressed = s4532807_hal_keypad_read_key();

            if ((s4532807_SemaphoreKeypadGrid != NULL) && (keypadMode == 0)) {	

    			/* Give Keypad Grid Semaphore */
    			xSemaphoreGive(s4532807_SemaphoreKeypadGrid);

    		} else if ((s4532807_SemaphoreKeypadMnemonic != NULL) && 
                        (keypadMode == 1)) {

    			/* Give Keypad Mnemonic Semaphore */
    			xSemaphoreGive(s4532807_SemaphoreKeypadMnemonic);

            }

            // clear event bits
            keyBits = xEventGroupClearBits(s4532807_EventKeypadKeyPress, 
                                           EVT_KEYPAD_CTRL);
            
            // set event bit for key pressed
            keyBits = xEventGroupSetBits(s4532807_EventKeypadKeyPress, 
                                             (1 << keyPressed));            
        }
        
		/* Delay for 30ms (fsmprocessing) */
		vTaskDelay(30);
	}    

}

/*
 * IRQ handler for the push button, debounces the press (300ms).
 */
extern void PUSHBUTTON_IRQ_HANDLER(void) {

    if ((HAL_GetTick() - pbLastTick) > 300) {
        if (keypadMode == 0) {
            BRD_LEDRedOff();
            BRD_LEDBlueOn();
            keypadMode = 1;
        } else if (keypadMode == 1) {
            BRD_LEDBlueOff();
            BRD_LEDRedOn();
            keypadMode = 0;
        }
    }

    pbLastTick = HAL_GetTick(); // update last tick
    
}

/*
 * Marks the interrupt handled.
 */
void EXTI15_10_IRQHandler(void) {
	HAL_GPIO_EXTI_IRQHandler(BRD_USER_BUTTON_PIN);
}
