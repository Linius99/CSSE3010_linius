/** 
 **************************************************************
 * @file mylib/s4532807_lib_hamming.h
 * @author Linius Zaman 45328077
 * @date 10/04/2020
 * @brief hamming driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern uint16_t s4532807_lib_hamming_byte_encode(uint8_t input)
 * - Returns the 16bit encoded value of a byte. 
 * extern uint8_t s4532807_lib_hamming_byte_decode(uint8_t input)
 * - Returns the decoded half byte from a byte. Errors detected and corrected.
 * extern int s4532807_lib_hamming_parity_error(uint8_t byte) 
 * - Return 1 if a parity error has occurred, else 0. 
 ***************************************************************
 * INTERNAL FUNCTIONS
 ***************************************************************
 * uint8_t hamming_hbyte_encode(uint8_t input)
 * - Internal function to Encode a half byte 
 *************************************************************** 
 */

#ifndef s4532807_lib_hamming_h_
#define s4532807_lib_hamming_h_

#include "board.h"
#include "stm32f4xx_hal.h"
#include "debug_printf.h"

#ifdef S4532807_MYLIB_CONFIGURE_INC
#include "s4532807_hal_mylib_configure.h"
#endif

/*
 * Function which performs hamming encoding on a byte one nibble at a time.
 * Calls the internal hbyte function to encode the MSB and LSB. Returns a 16bit
 * output which has the original two chars and their encoded chars.
 */
extern uint16_t s4532807_lib_hamming_byte_encode(uint8_t input);

/*
 * This function performs hamming decoding on a byte. The syndrome is calculated
 * to check for errors. 1 bit errors are corrected in data or hamming bits and 
 * the corrected byte is returned. 
 */
extern uint8_t s4532807_lib_hamming_byte_decode(uint8_t input);

/*
 * This function compares the given parity in the byte to its calculated parity
 * returns 1 if there is a parity error, 0 otherwise.
 */
extern int s4532807_lib_hamming_parity_error(uint8_t byte);

/*
 * Internal function which performs hamming encoding on a nibble (half byte)
 * Parity is calculated and appended to the encoded output which is returned.
 */
uint8_t hamming_hbyte_encode(uint8_t input);

#endif


