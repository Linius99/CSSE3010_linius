/** 
 **************************************************************
 * @file mylib/s4532807_lib_hamming.c
 * @author Linius Zaman 45328077
 * @date 10/04/2020
 * @brief hamming driver
 ***************************************************************
 * EXTERNAL FUNCTIONS 
 ***************************************************************
 * extern uint16_t s4532807_lib_hamming_byte_encode(uint8_t input)
 * - Returns the 16bit encoded value of a byte. 
 * extern uint8_t s4532807_lib_hamming_byte_decode(uint8_t input)
 * - Returns the decoded half byte from a byte. Errors detected and corrected.
 * extern int s4532807_lib_hamming_parity_error(uint8_t byte) 
 * - Return 1 if a parity error has occurred, else 0. 
 ***************************************************************
 * INTERNAL FUNCTIONS
 ***************************************************************
 * uint8_t hamming_hbyte_encode(uint8_t input)
 * - Internal function to Encode a half byte 
 *************************************************************** 
 */

#include "s4532807_lib_hamming.h"

/*
 * Function which performs hamming encoding on a byte one nibble at a time.
 * Calls the internal hbyte function to encode the MSB and LSB. Returns a 16bit
 * output which has the original two chars and their encoded chars.
 */
extern uint16_t s4532807_lib_hamming_byte_encode(uint8_t input) {
    uint16_t out;
    
	/* first encode D0..D3 (first 4 bits),
	 * then D4..D7 (second 4 bits).
	 */
	out = hamming_hbyte_encode(input & 0xF) |
		(hamming_hbyte_encode(input >> 4) << 8);

	return out;
}

/*
 * This function performs hamming decoding on a byte. The syndrome is calculated
 * to check for errors. 1 bit errors are corrected in data or hamming bits and 
 * the corrected byte is returned. 
 */
extern uint8_t s4532807_lib_hamming_byte_decode(uint8_t input) {
    uint8_t d0, d1, d2, d3;
	uint8_t p0 = 0, h0, h1, h2;
	uint8_t out, s0, s1, s2;
    uint8_t syndrome = 0x00;           
        
    p0 = !!((input & 0x01));

    //parity bits

    h0 = (input >> 1) & 0x1;
    h1 = (input >> 2) & 0x1;
    h2 = (input >> 3) & 0x01;

    //data bits
    d3 = !!(input & 0x80);
    d2 = !!(input & 0x40);
    d1 = !!(input & 0x20);
    d0 = !!(input & 0x10);

    //sydrome calculation
    s0 = h0 ^ d1 ^ d2 ^ d3;  
    s1 = h1 ^ d0 ^ d2 ^ d3;
    s2 = h2 ^ d0 ^ d1 ^ d3;

    syndrome = (s0 << 0) + (s1 << 1) + (s2 << 2);

    if (syndrome == 0x00) {
        // no error, no need to correct
        out = (0 | d3 << 3 | d2 << 2 | d1 << 1| d0);
    } else {     
        // error found, flip the bit where it has occured
        if (syndrome == 0x07) {
            d3 = !d3; 
        } else if (syndrome == 0x06) {
            d0 = !d0; 
        } else if (syndrome == 0x05) {
            d1 = !d1; 
        } else if (syndrome == 0x04) {
            h2 = !h2; 
        } else if (syndrome == 0x03) {
            d2 = !d2; 
        } else if (syndrome == 0x02) {
            h1 = !h1; 
        } else if (syndrome == 0x01) {
            h0 = !h0; 
        }
        out = (0 | d3 << 3 | d2 << 2 | d1 << 1| d0);
    }
    return out;
}

/*
 * This function compares the given parity in the byte to its calculated parity
 * returns 1 if there is a parity error, 0 otherwise.
 */
extern int s4532807_lib_hamming_parity_error(uint8_t byte) {
    int error = 0;
    uint8_t parityGiven;
    uint8_t parityCalc = 0;
    
    // extract given parity
    parityGiven = (byte & 0x01); // get p0 bit    

    // calculate parity
    for (int z = 1; z < 8; z++) {
    	parityCalc = parityCalc ^ !!(byte & (1 << z));
    }

    if (parityGiven != parityCalc) { // check if same
        error = 1;
    }
    
    return error;
}

/*
 * Internal function which performs hamming encoding on a nibble (half byte)
 * Parity is calculated and appended to the encoded output which is returned.
 */
uint8_t hamming_hbyte_encode(uint8_t input) {
    uint8_t d0, d1, d2, d3;
	uint8_t p0 = 0, h0, h1, h2;
	uint8_t z;
	uint8_t out;   

    d0 = !!(input & 0x1);
    d1 = !!(input & 0x2);
    d2 = !!(input & 0x4);
    d3 = !!(input & 0x8);

    h0 = d1 ^ d2 ^ d3; 
    h1 = d0 ^ d2 ^ d3;
    h2 = d0 ^ d1 ^ d3;

    /* generate  byte without parity bit P0 */
    out = (h0 << 1) | (h1 << 2) | (h2 << 3) | 
          (d0 << 4) | (d1 << 5) | (d2 << 6) | (d3 << 7);

    //Calculate parity bit 
    for (z = 1; z < 8; z++) {
    	p0 = p0 ^ !!(out & (1 << z));
    }

    out |= p0;

	return out;
}
