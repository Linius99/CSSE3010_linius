/* hal.h
 * Created: 2/1/2020
 * Updated: 2/1/2020
 * Author: mds
 */

#ifndef PROCESSOR_HAL_H
#define PROCESSOR_HAL_H

#include "stm32f4xx_hal.h"



#endif /* BOARD_HAL_H_ */

