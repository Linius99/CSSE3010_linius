#ifndef __NETIF_INIT_H
#define __NETIF_INIT_H

struct netif gnetif; /* network interface structure */

void Netif_Config(void);

#endif
