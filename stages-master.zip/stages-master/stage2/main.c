/**
  ******************************************************************************
  * @file    main.c
  * @author  Linius Zaman
  * @date    27/03/2020
  * @brief   Main file for stage2
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "board.h"
#include "processor_hal.h"
#include "debug_printf.h"
#include "s4532807_hal_atimer.h"
#include "s4532807_hal_iss.h"
#include "s4532807_hal_pwm.h"
#include "s4532807_hal_lta1000g.h"
#include "s4532807_hal_joystick.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/

/**
  * @brief  Initialise Hardware
  * @param  None
  * @retval None
  */
void Hardware_init(void);

/**
  * @brief  Main program - performs stage2 tasks
  * @param  None
  * @retval None
  */
void main(void)  {
	BRD_init();			//Initalise Board
	Hardware_init();	//Initalise hardware modules
    char receivedChar;
    int ticks;
    int ms;
    int period = 2;
    int frequency = 25000;
    int joyX;
    int joyY;
    int ledStatus = 1;
    int barControl = 0;
    int lastZ = 0;
    
	/* Main processing loop */
    while (1) {
        
        receivedChar = debug_getc();

        if (receivedChar == 'f') {
            s4532807_hal_atimer_timer_pause();
        } else if (receivedChar == 'r') {
            s4532807_hal_atimer_timer_resume();
        } else if (receivedChar == 'z') {
            s4532807_hal_atimer_timer_reset();
        } else if (receivedChar == 'c') {
            ticks = s4532807_hal_atimer_timer_read();
            debug_printf("Atimer ticks: %d\n\r", ticks);
        } else if (receivedChar == 't') {
            ms = s4532807_hal_atimer_timer_getms();
            debug_printf("Atimer ms: %d\n\r", ms);
        } else if (receivedChar == '+') {
            period += 5;
            s4532807_hal_atimer_period_set(period);
        } else if (receivedChar == '-') {
            period -= 5;
            if (period > 0) {
                s4532807_hal_atimer_period_set(period);
            } else {
                period = 0;
                s4532807_hal_atimer_period_set(0);
            }
        } else if (receivedChar == 'i') {
            frequency += 1000;
            s4532807_hal_atimer_clkspeed_set(frequency);
        } else if (receivedChar == 'd') {
            frequency -= 1000;
            if (frequency > 0) {
                s4532807_hal_atimer_clkspeed_set(frequency); 
            } else {
                frequency = 0;
                s4532807_hal_atimer_clkspeed_set(0);
            }
        }

        joyX = S4532807_HAL_JOYSTICK_X_READ();
        joyY = S4532807_HAL_JOYSTICK_Y_READ();        
        
        if (lastZ < s4532807_hal_iss_eventcounter_read(2)) {
            if (ledStatus == 1) {
                // switch LEDs off
                ledStatus = 0;
                barControl = 0;
                s4532807_hal_lta1000g_write(0b0000000000000000);
            } else {
                // switch LEDs on
                ledStatus = 1;           
            }        
        }

        if (ledStatus == 1) {
            barControl = (joyY * 100)/4096;    
            s4532807_hal_pwm_dc_set(joyX/4096.0);
            
            if (barControl < 10) {
                s4532807_hal_lta1000g_write(0b0000000000000000);
            } else if (barControl < 20) {
                s4532807_hal_lta1000g_write(0b0000000000000001);
            } else if (barControl < 30) {
                s4532807_hal_lta1000g_write(0b0000000000000011);
            } else if (barControl < 40) {
                s4532807_hal_lta1000g_write(0b0000000000000111);
            } else if (barControl < 50) {
                s4532807_hal_lta1000g_write(0b0000000000001111);
            } else if (barControl < 60) {
                s4532807_hal_lta1000g_write(0b0000000000011111);
            } else if (barControl < 70) {
                s4532807_hal_lta1000g_write(0b0000000000111111);
            } else if (barControl < 80) {
                s4532807_hal_lta1000g_write(0b0000000001111111);
            } else if (barControl < 90) {
                s4532807_hal_lta1000g_write(0b0000000011111111);
            } else if (barControl < 95) {
                s4532807_hal_lta1000g_write(0b0000000111111111);        
            } else {
                s4532807_hal_lta1000g_write(0b0000001111111111);
            }       
        }
        lastZ = s4532807_hal_iss_eventcounter_read(2);
	}
}

/**
  * @brief  Initialise Hardware
  * @param  None
  * @retval None
  */
void Hardware_init(void) {	
    s4532807_hal_iss_init();	
    s4532807_hal_lta1000g_init();
    s4532807_hal_atimer_init();
    s4532807_hal_joystick_init();
    s4532807_hal_pwm_init();   
}

