/** 
 **************************************************************
 * @file mylib/s4532807_hal_mylib_config.h
 * @author Linius Zaman 45328077
 * @date 27/03/2020
 * @brief mylib config file
 ***************************************************************
 */

#ifndef s4532807_hal_mylib_configure_h_
#define s4532807_hal_mylib_configure_h_


//ATIMER
#define S4532807_HAL_ATIMER_PIN BRD_D10_PIN
#define S4532807_HAL_ATIMER_PINPORT BRD_D10_GPIO_PORT
#define S4532807_HAL_ATIMER_PINCLK __BRD_D10_GPIO_CLK()
#define S4532807_HAL_ATIMER_PERIOD 2
#define S4532807_HAL_ATIMER_CLKSPEED 25000

//PWM
#define S4532807_HAL_PWM_CLOCKFREQ 50000
#define S4532807_HAL_PWM_PULSEPERIOD 12500
#define S4532807_HAL_PWM_PERIOD 25000
#define S4532807_HAL_PWM_CHANNEL TIM_CHANNEL_1
#define S4532807_HAL_PWM_TIMER TIM1
#define S4532807_HAL_PWM_TIMER_CLK() __TIM1_CLK_ENABLE()
#define S4532807_HAL_PWM_TIMER_HANDLER TIMER_INIT
#define S4532807_HAL_PWM_PIN BRD_D6_PIN
#define S4532807_HAL_PWM_PINGPIOPORT BRD_D6_GPIO_PORT
#define S4532807_HAL_PWM_PINGPIOAF GPIO_AF1_TIM1
#define S4532807_HAL_PWM_PINCLK __BRD_D6_GPIO_CLK()
#define S4532807_HAL_PWM_PINCLKSPEED GPIO_SPEED_FAST

#endif
