/**
  ******************************************************************************
  * @file    project/main.c
  * @author  45328077 LINIUS ZAMAN 
  * @date    28/05/2020
  * @brief   CGoL CAG Project - Displays CGoL Simulations to terminal using
  *          vt100 escape sequences. Can be controlled by joystick and keypad  
  *          while lta1000g LEDbar indicates simulation and subgrid status.
  ******************************************************************************
  */

/* Includes */
#include <stdio.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "board.h"
#include "debug_printf.h"

#include "s4532807_os_lta1000g.h"
#include "s4532807_os_joystick.h"
#include "s4532807_os_keypad.h"

#include "s4532807_os_CAG_Simulator.h"
#include "s4532807_os_CAG_Display.h"
#include "s4532807_os_CAG_keypad_grid.h"
#include "s4532807_os_CAG_keypad_mnemonic.h"
#include "s4532807_os_CAG_joystick.h"

void ApplicationIdleHook(void); // The idle hook is used to do nothing yet
void Hardware_init(void); // hardware initialise function

/*
 * Main function for the project. Simply intialises nucleo board and calls
 * Hardware_init function to initialise all peripherals. Control is then handed 
 * over to the scheduler. 
 */
int main(void) {

	BRD_init();
	Hardware_init();

	// hand over to scheduler
	vTaskStartScheduler();

	/* We should never get here as control is now taken by the scheduler. */
	return 0;

}


/**
  * @brief  Hardware Initialisation.
  * @param  None
  * @retval None
  */
void Hardware_init(void) {

	portDISABLE_INTERRUPTS();	//Disable interrupts

    s4532807_os_keypad_init(); // initialise PMOD keypad os driver   
    s4532807_os_lta1000g_init(); // initialise lta1000g os driver
    s4532807_os_joystick_init(); // initialise joystick os driver

    s4532807_os_CAG_Simulator_init(); // init CAG simulator
    s4532807_os_CAG_Display_init(); // init CAG display
    s4532807_os_CAG_joystick_init(); // init joystick CAG
    s4532807_os_CAG_keypad_grid_init(); // init CAG keypad grid  
    s4532807_os_CAG_keypad_mnemonic_init(); // init CAG keypad mnemonic

	portENABLE_INTERRUPTS();	//Enable interrupts

}

/**
  * @brief  Application Tick Task, NOT IMPLEMENTED
  * @param  None
  * @retval None
  */
void vApplicationTickHook(void) {

}


/**
  * @brief  Idle Application Task, NOT IMPLEMENTED
  * @param  None
  * @retval None
  */
void vApplicationIdleHook(void) {

}

/**
  * @brief  vApplicationStackOverflowHook
  * @param  Task Handler and Task Name
  * @retval None
  */
void vApplicationStackOverflowHook(xTaskHandle pxTask, 
                                   signed char *pcTaskName) {

	/* This function will get called if a task overflows its stack.   If the
	parameters are corrupt then inspect pxCurrentTCB to find which was the
	offending task. */
	( void ) pxTask;
	( void ) pcTaskName;

	for( ;; );

}
