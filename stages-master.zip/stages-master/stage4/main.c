/**
  ******************************************************************************
  * @file    stage4/main.c
  * @author  45328077 LINIUS ZAMAN 
  * @date    28/04/2020
  * @brief   LED dual timer (binary counter) program which is controlled by 
  *          joystick Z press, uses FreeRTOS tasks, queues & binary semaphore
  ******************************************************************************
  */

#include <stdio.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "board.h"
#include "debug_printf.h"
#include "s4532807_os_lta1000g.h"
#include "s4532807_os_joystick.h"


/* Task Priorities -----------------------------------------------------------*/
#define TASKTIMERLEFT_PRIORITY	            ( tskIDLE_PRIORITY + 5 )
#define TASKTIMERRIGHT_PRIORITY             ( tskIDLE_PRIORITY + 5 )
#define TASKTIMERDISPLAY_PRIORITY	        ( tskIDLE_PRIORITY + 3 )
#define TASKTIMERCONTROL_PRIORITY	        ( tskIDLE_PRIORITY + 4 )

/* Task Stack Allocations ----------------------------------------------------*/
#define TASKTIMERLEFT_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )
#define TASKTIMERRIGHT_TASK_STACK_SIZE		( configMINIMAL_STACK_SIZE * 2 )
#define TASKTIMERDISPLAY_TASK_STACK_SIZE	( configMINIMAL_STACK_SIZE * 2 )
#define TASKTIMERCONTROL_TASK_STACK_SIZE	( configMINIMAL_STACK_SIZE * 2 )


// task handles for left and right timer so they can be suspended/resumed
TaskHandle_t TaskTimerLeftHandle;
TaskHandle_t TaskTimerRightHandle;

// integer for storing timer status, 0 when stopped, 1 when started
unsigned int timerStatus = 1;

// queue for writing left/right timer value to TimerDisplay task
QueueHandle_t queueTimerDisplay; 

// struct to store dual timer message
struct dualTimerMsg {
    char type; // either l or r
    unsigned char timerValue; // value of respective timer
};

void ApplicationIdleHook(void); // The idle hook is used to do nothing yet
void TaskTimerLeft(void); // left counter
void TaskTimerRight(void); // right counter
void TaskTimerDisplay(void); // timer display task
void TaskTimerControl(void); // controller task
void Hardware_init(void); // hardware initialise function

/*
 * Main function for this stage. Initialises board and the GPIO by calling 
 * Hardware init. Creates the left, right and timer display tasks as well as a
 * controlling task (which toggles both timers based on joystick Z binary
 * semaphore). Control is then handed over to the scheduler. 
 */
int main(void) {

	BRD_init();
	Hardware_init();

	// create timer left task
    xTaskCreate( (void *) &TaskTimerLeft, (const signed char *) "LEFT", 
            TASKTIMERLEFT_TASK_STACK_SIZE, NULL, TASKTIMERLEFT_PRIORITY, 
                                                          &TaskTimerLeftHandle);
    // create timer right task
    xTaskCreate( (void *) &TaskTimerRight, (const signed char *) "RIGHT", 
           TASKTIMERRIGHT_TASK_STACK_SIZE, NULL, TASKTIMERRIGHT_PRIORITY, 
                                                         &TaskTimerRightHandle);
    // create timer display task
    xTaskCreate( (void *) &TaskTimerDisplay, (const signed char *) "DISPLAY", 
       TASKTIMERDISPLAY_TASK_STACK_SIZE, NULL, TASKTIMERDISPLAY_PRIORITY, NULL);

    // create timer control task
    xTaskCreate( (void *) &TaskTimerControl, (const signed char *) "CONTROL", 
       TASKTIMERCONTROL_TASK_STACK_SIZE, NULL, TASKTIMERCONTROL_PRIORITY, NULL);

	// hand over to scheduler
	vTaskStartScheduler();

	/* We should never get here as control is now taken by the scheduler. */
	return 0;

}

/*
 * Left timer task; counts up in binary every 1 second. Stores the binary value
 * to a dualTimerMsg struct of type 'l' then writes struct to queueTimerDisplay 
 * queue. Resets timer at the count of 31 (max 5 bit binary value)
 */
void TaskTimerLeft(void) {

    struct dualTimerMsg leftMessage;

    queueTimerDisplay = xQueueCreate(10, sizeof(leftMessage));

    leftMessage.type = 'l';
    leftMessage.timerValue = 0b00000000;

    for (;;) {

        if (queueTimerDisplay != NULL) {	/* Check if queue exists */

			/*Send message to the front of the queue - wait atmost 10 ticks */
			if(xQueueSendToFront(queueTimerDisplay, (void *) &leftMessage, 
                                                (portTickType) 10 ) != pdPASS) {
				portENTER_CRITICAL();
				debug_printf("Failed to post after 10 ticks.\n\r");
				portEXIT_CRITICAL();
			}
		}

		/* Wait for 1s */
		vTaskDelay(1000);
        leftMessage.timerValue++;

        if (leftMessage.timerValue == 32) {
            leftMessage.timerValue = 0;
        }
	}

}

/*
 * Right timer task; counts up in binary every 0.1 second. Stores binary value
 * to a dualTimerMsg struct of type 'r' then writes struct to queueTimerDisplay 
 * queue. Resets timer at the count of 31 (max 5 bit binary value)
 */
void TaskTimerRight(void) {

    struct dualTimerMsg rightMessage;

    rightMessage.type = 'r';
    rightMessage.timerValue = 0b00000000;

    for (;;) {

        if (queueTimerDisplay != NULL) {	/* Check if queue exists */

			/*Send message to the front of the queue - wait atmost 10 ticks */
			if(xQueueSendToFront(queueTimerDisplay, (void *) &rightMessage, 
                                                (portTickType) 10 ) != pdPASS) {
				portENTER_CRITICAL();
				debug_printf("Failed to post after 10 ticks.\n\r");
				portEXIT_CRITICAL();
			}
		}

		/* Wait for 0.1s */
		vTaskDelay(100);
        rightMessage.timerValue++;

        if (rightMessage.timerValue == 32) {
            rightMessage.timerValue = 0;
        }
	}

}

/*
 * Timer Display task; reads messages from the TimerDisplay queue, determines
 * which timer wrote the message, then bit shifts the timerValue accordingly
 * before writing to the Lta1000g queue. 
 */
void TaskTimerDisplay(void) {   
   
    struct dualTimerMsg receivedMessage;
    uint16_t ledBitsSend = 0b0000000000000000; // store LED value being sent
        
    for (;;) {
        if (queueTimerDisplay != NULL) {	/* Check if queue exists */

			/* Check for item received - block atmost for 10 ticks */
			if (xQueueReceive(queueTimerDisplay, &receivedMessage, 10)) {
                
                // bit shift LED bar value based on message
                if (receivedMessage.type == 'l') {
                    ledBitsSend = (receivedMessage.timerValue << 5) | 
                              (ledBitsSend & 0b0000011111);
                } else if (receivedMessage.type == 'r') {
                    ledBitsSend = (ledBitsSend & 0b1111100000) | 
                              (receivedMessage.timerValue);
                }

                // write LED value to lta1000g queue
                if (s4532807_QueueLta1000gWrite != NULL) {
			        if(xQueueSendToFront(s4532807_QueueLta1000gWrite, 
                                         (void *) &ledBitsSend, 
                                         (portTickType) 10 ) != pdPASS) {
				        portENTER_CRITICAL();
				        debug_printf("Failed to post after 10 ticks.\n\r");
				        portEXIT_CRITICAL();
			        }
		        }
        	}
		}

		/* Delay for 1ms */
		vTaskDelay(1);
	}

}

/*
 * Controlling task for the dual timers. Attempts to take the joystick Z 
 * semaphore. If Z semaphore is obtained, this task toggles the start/stop 
 * state of the dual timers by suspending or resuming both of the timers.
 */
void TaskTimerControl(void) {

    for (;;) {
        
        if (s4532807_SemaphoreJoystickZ != NULL) { // check semaphore exists
            
            // see if semaphore can be obtained, try for 10 ticks
            if(xSemaphoreTake(s4532807_SemaphoreJoystickZ, 10) == pdTRUE) { 
                if (timerStatus == 0) { // timer was stopped; resume tasks
                    timerStatus = 1;
                    vTaskResume(TaskTimerLeftHandle);
                    vTaskResume(TaskTimerRightHandle);
                } else if (timerStatus == 1) { // timer running; suspend tasks
                    timerStatus = 0;
                    vTaskSuspend(TaskTimerLeftHandle);
                    vTaskSuspend(TaskTimerRightHandle);
                }
            }
        }
        vTaskDelay(1);
    }

}

/**
  * @brief  Hardware Initialisation.
  * @param  None
  * @retval None
  */
void Hardware_init(void) {

	portDISABLE_INTERRUPTS();	//Disable interrupts
    
    s4532807_os_lta1000g_init(); // initialise lta1000g
    s4532807_os_joystick_init(); // initialise joystick

	portENABLE_INTERRUPTS();	//Enable interrupts

}

/**
  * @brief  Application Tick Task, NOT IMPLEMENTED
  * @param  None
  * @retval None
  */
void vApplicationTickHook(void) {

}


/**
  * @brief  Idle Application Task, NOT IMPLEMENTED
  * @param  None
  * @retval None
  */
void vApplicationIdleHook(void) {

}

/**
  * @brief  vApplicationStackOverflowHook
  * @param  Task Handler and Task Name
  * @retval None
  */
void vApplicationStackOverflowHook(xTaskHandle pxTask, 
                                   signed char *pcTaskName) {

	/* This function will get called if a task overflows its stack.   If the
	parameters are corrupt then inspect pxCurrentTCB to find which was the
	offending task. */

	( void ) pxTask;
	( void ) pcTaskName;

	for( ;; );

}
