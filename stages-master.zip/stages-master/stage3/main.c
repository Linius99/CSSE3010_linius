/**
  ******************************************************************************
  * @file    main.c
  * @author  Linius Zaman
  * @date    27/03/2020
  * @brief   Main file for stage3
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "board.h"
#include "processor_hal.h"
#include "debug_printf.h"
#include "s4532807_hal_atimer.h"
#include "s4532807_hal_keypad.h"
#include "s4532807_lib_hamming.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define IDLE_STATE 0
#define ENCODE_STATE 1
#define DECODE_STATE 2
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/

/**
  * @brief  Initialise Hardware
  * @param  None
  * @retval None
  */
void Hardware_init(void);

/**
  * @brief  Main program - performs stage3 tasks
  * @param  None
  * @retval None
  */
void main(void)  {
	BRD_init();			// Initalise Board
	Hardware_init();	// Initalise hardware modules

    // Initialise variables
    int tick = 0;
    int lastTick = 0;   
    int charCount = 0; 
    int keyPressed = 0;
    unsigned int currentState = IDLE_STATE;
    unsigned char lastChar = '0';
    uint8_t hexLastChar = 0;

    uint8_t encodeIn = 0;
    uint16_t encodeOut = 0;
    uint8_t decodeIn = 0;
    uint16_t decodeOut = 0;          
    int parity = 0;

	/* Main processing loop */
    while (1) {        
          
        tick = HAL_GetTick(); // get current tick
        if ((tick - lastTick) >= 50) { // if 50ms has passed since last tick
            
            // process the keypad FSM            
            s4532807_hal_keypad_fsmprocessing();
            
            // get KeypadStatus value and store internally
            if (s4532807_hal_keypad_read_status() == 1) {
                keyPressed = 1;
                charCount += 1; // increment charCount
            } else {
                keyPressed = 0;
            }
            
            // IDLE_STATE
            if ((currentState == IDLE_STATE) && (keyPressed == 1)) {
                
                // if last two keys were EE proceed to encode state
                if ((charCount >= 2) && (lastChar == 'E') &&
                    (s4532807_hal_keypad_read_ascii() == 'E')) {
                    
                    currentState = ENCODE_STATE;
                    charCount = 0;                    

                // if last two keys were DD proceed to decode state
                } else if ((charCount >= 2) && (lastChar == 'D') &&
                    (s4532807_hal_keypad_read_ascii() == 'D')) {

                    currentState = DECODE_STATE;
                    charCount = 0;
                }
                debug_printf("<%c>", s4532807_hal_keypad_read_ascii()); 
                lastChar = s4532807_hal_keypad_read_ascii(); // update last char
                keyPressed = 0;
            }

            // ENCODE_STATE
            if ((currentState == ENCODE_STATE) && (keyPressed == 1)) {
                // if last two keys were FF go back to idle state
                if ((charCount >= 2) && (lastChar == 'F') &&
                    (s4532807_hal_keypad_read_ascii() == 'F')) {
                                        
                    currentState = IDLE_STATE;
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii());
                    charCount = 0;

                // if last two keys were DD proceed to decode state
                } else if ((charCount >= 2) && (lastChar == 'D') &&
                    (s4532807_hal_keypad_read_ascii() == 'D')) {

                    currentState = DECODE_STATE;
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii());
                    charCount = 0;

                } else if (charCount >= 2) {
                    // ENCODE procedure
                    // combine last 2 chars into a byte
                    encodeIn = (hexLastChar << 4) |
                               (s4532807_hal_keypad_read_key());
                        
                    // encode the byte
                    encodeOut = s4532807_lib_hamming_byte_encode(encodeIn);
                        
                    // print last char as usual                                                                    
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii());
                        
                    // print the encoded output
                    debug_printf("\n\rHE %04x\n\r", encodeOut);
                    charCount = 0;
                } else {
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii()); 
                }
                lastChar = s4532807_hal_keypad_read_ascii(); // update last char
                hexLastChar = s4532807_hal_keypad_read_key(); // get hex val
                keyPressed = 0;
            }

            // DECODE_STATE
            if ((currentState == DECODE_STATE) && (keyPressed == 1)) {
                // if last two keys were FF go back to idle state
                if ((charCount >= 2) && (lastChar == 'F') &&
                    (s4532807_hal_keypad_read_ascii() == 'F')) {

                    currentState = IDLE_STATE;
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii());
                    charCount = 0;

                // if last two keys were EE proceed to encode state
                } else if ((charCount >= 2) && (lastChar == 'E') &&
                    (s4532807_hal_keypad_read_ascii() == 'E')) {

                    currentState = ENCODE_STATE;
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii());
                    charCount = 0;

                } else if (charCount >= 2) {
                    // DECODE procedure
                    // combine last 2 chars into a byte
                    decodeIn = (hexLastChar << 4) |
                               (s4532807_hal_keypad_read_key());
                        
                    // decode the byte
                    decodeOut = s4532807_lib_hamming_byte_decode(decodeIn);
                    
                    // check for parity error
                    parity = s4532807_lib_hamming_parity_error(decodeIn);
         
                    // print last char as usual                                                                    
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii());
                        
                    // print the decoded output
                    debug_printf("\n\rHD %x P%d\n\r", decodeOut, parity);
                    charCount = 0;
                } else {
                    debug_printf("<%c>", s4532807_hal_keypad_read_ascii()); 
                }
                lastChar = s4532807_hal_keypad_read_ascii(); // update last char
                hexLastChar = s4532807_hal_keypad_read_key(); // get hex val
                keyPressed = 0;
            }
            lastTick = tick; // update last stored tick        
        }
    }
}

/**
  * @brief  Initialise Hardware
  * @param  None
  * @retval None
  */
void Hardware_init(void) {	
    s4532807_hal_atimer_init();
    keypad_gpio_init();
    s4532807_hal_keypad_init();   
}
